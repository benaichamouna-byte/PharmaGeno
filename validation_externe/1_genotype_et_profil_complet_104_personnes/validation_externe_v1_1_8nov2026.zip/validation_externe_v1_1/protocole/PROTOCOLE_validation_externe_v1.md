# Protocole v1 — Validation externe des recommandations par les études publiées
Date de rédaction : 8 novembre 2026 (avant tout calcul de verdict). Code associé : `validation_externe_v1.py` (empreinte dans `EMPREINTES_PROTOCOLE_v1.txt`).

## Question
Pour un même gène, un même état métaboliseur et un même médicament, les études publiées annotées dans ClinPGx vont-elles dans le sens de l'alerte de l'application (éviter / adapter la dose / surveiller) ?

## Source de comparaison (lecture seule)
- ClinPGx, dump d'octobre 2026 : `var_drug_ann.tsv` (réponse au médicament, dose, pharmacocinétique) et `var_pheno_ann.tsv` (effets indésirables, toxicité). Les 27 590 lignes sont utilisées avec TOUTES leurs valeurs de significativité (oui / non / non précisé), y compris les résultats nuls. Le fichier CSV du projet (6 063 lignes) est abandonné : il ne gardait que les associations significatives et omettait les études de toxicité.
- Aucun PMID de ces annotations n'est un article de guide CPIC/DPWG (83 PMID de guides vérifiés dans `guidelineAnnotations.json` : chevauchement 0). Les annotations d'étiquettes de médicaments ne sont pas dans ces fichiers.
- Fonction des allèles : table `allele-table.csv` de PyPGx 0.27.0 (empreinte dans `entrees_sha256.txt`).
- Règles de l'application : `regles_v14_monogene.csv`, lignes dont l'action n'est pas STANDARD (285 règles, 152 couples gène–médicament).

## Appariement d'une ligne d'étude à une règle (toutes les conditions)
1. Même gène (pour HLA-B*15:02 : gène HLA-B et allèle *15:02 cité dans la variante du sujet, absent du comparateur).
2. Même médicament : nom identique (sans tenir compte de la casse). Pour un nom de règle combiné (« A / B » ou « A and B »), un composant identique est accepté et marqué « composant ». Aucun rapprochement de sels, métabolites ou synonymes (ex. « simvastatin acid » n'est pas « simvastatin »).
3. Classe du sujet de l'étude (priorité au champ « Metabolizer types », sinon champ « Alleles » traduit par la table PyPGx) :
   - PM_like / IM_like / UM_like / RM_like : texte explicite (poor, slow, intermediate, ultrarapid, rapid).
   - Allèles : diplotype avec deux allèles « No Function » = PM_like ; au moins un allèle diminué/sans fonction = REDUIT_GEN ; allèle augmenté ou duplication d'un allèle normal = AUGMENTE_GEN ; tous normaux = NORMAL ; allèle de fonction incertaine/inconnue, génotype par rsID seul, ou mélange = INCONNU.
   - Comparateur (champs « Comparison … ») traité de même. Sujet normal contre comparateur réduit/augmenté : on prend la classe du comparateur et on inverse la direction. Comparaison entre deux classes non normales (ex. PM contre IM) : exclue.
4. Compatibilité avec l'état de la règle (valeur 0,0 = PM ; 0,25 / 0,5 / 0,75 = IM ; 1,5 = RM ; 2,0 = UM) : PM ↔ PM_like ou REDUIT_GEN ; IM ↔ IM_like ou REDUIT_GEN ; RM ↔ RM_like ou AUGMENTE_GEN ; UM ↔ UM_like ou AUGMENTE_GEN. Règles HLA : sujet porteur de l'allèle.
5. Gènes F5, G6PD, CYP3A5 : classification automatique non définie (les études décrivent des variants nommés ou par rsID). Les lignes candidates sont listées et lues à la main (étape 3).

## Résultat d'une ligne
- Positif : « Associated with » ET significativité « yes ». Nul : « Not associated with » (quelle que soit la significativité). Douteux : « Associated with » avec significativité « no » ou « not stated » → exclu des verdicts, compté à part.
- Type : TOX (toxicité, fichier var_pheno_ann), EFF (« response to », « clinical benefit to »), EFF_INV (« resistance to »), DOSE (« dose of »), PK (concentrations, exposition, demi-vie, clairance, métabolisme), AUTRE.
- Orientation d'un positif (après inversion éventuelle du signe) :
  - TOX augmentée = concordant ; TOX diminuée = discordant.
  - EFF diminuée = concordant ; EFF augmentée = non orienté (ni pour ni contre). EFF_INV augmentée = concordant.
  - DOSE et PK : orientés seulement si la recommandation de la règle donne un sens de dose (DOWN ou UP détecté dans le texte par expressions régulières figées ; sinon NA = non orienté). Dose étude dans le même sens que la règle = concordant ; sens opposé = discordant. PK : exposition plus haute (concentration, exposition, demi-vie en hausse ; clairance ou métabolisme en baisse) concorde avec une règle DOWN ; exposition plus basse concorde avec une règle UP.
  - Les autres types positifs = « signal non orienté ».
- Un résultat nul compte comme « contre » seulement pour TOX, EFF, EFF_INV, et pour DOSE/PK si la règle a un sens de dose ; sinon il est listé mais ne compte pas.

## Verdict d'une règle (comptes en PMID distincts)
C = PMID avec au moins une ligne concordante ; X = PMID avec au moins une ligne discordante ou nulle pertinente.
- SOUTENUE : C non vide et X \ C vide.
- MIXTE : C non vide et X \ C non vide.
- NON_SOUTENUE : C vide et X non vide.
- SIGNAL_NON_ORIENTE : C et X vides, au moins un positif non orienté.
- AUTRE_PHENOTYPE : des lignes existent pour le couple gène–médicament mais aucune n'a un état compatible.
- NON_CLASSABLE_AUTO : lignes existantes mais aucune classable automatiquement.
- AUCUNE_ETUDE : aucune ligne pour le couple gène–médicament.
- A_LIRE_A_LA_MAIN : F5, G6PD, CYP3A5 avec lignes candidates.

## Étapes manuelles (déclarées avant le calcul)
- Relecture : 30 règles tirées au hasard parmi celles qui ont un verdict automatique SOUTENUE, MIXTE ou NON_SOUTENUE (graine 20261108, `random.Random(20261108).sample`), plus toutes les règles NON_SOUTENUE et MIXTE, plus les règles EVITER à lire à la main (HLA, G6PD, F5). Je lis les phrases ClinPGx et note : verdict automatique confirmé, corrigé, ou non tranchable. Toute correction est tracée à côté du verdict automatique (jamais écrasé).
- Les articles eux-mêmes ne sont pas lus pour cette étape ; seules les phrases curées de ClinPGx le sont. Les articles pivots (HLA-B*58:01, TAILOR-PCI, EU-PACT, COAG, etc.) sont lus séparément et cités seulement s'ils ont été réellement lus.

## Limites connues (écrites avant)
- Biais de publication et biais de sélection de ClinPGx ; association ≠ bénéfice clinique ; l'effectif des études n'est pas pondéré.
- Un résultat nul est compté dès qu'il existe, quelle que soit la taille de l'étude (peut surestimer les « contre »).
- Efficacité diminuée est comptée concordante pour toute alerte, même si l'alerte repose sur la toxicité (biais en faveur du soutien).
- PM_like / IM_like ne se distinguent que si l'étude les distingue ; REDUIT_GEN apparie les deux.
- Les noms de médicaments sont appariés exactement : couverture sous-estimée.
- Les règles v14 et ClinPGx partagent des sources de fond (même littérature) : cette validation teste la cohérence avec les études, pas l'indépendance totale des preuves.
- Les alertes issues d'étiquettes FDA/EMA reposent souvent sur des données qui ne sont pas dans ClinPGx.
