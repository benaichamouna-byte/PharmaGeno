import csv, sys, collections
R=list(csv.DictReader(open('sortie_v1_1/verdict_par_regle_auto_v1.csv')))
L=list(csv.DictReader(open('sortie_v1_1/lignes_etudes_appariees_v1.csv')))
by=collections.defaultdict(list)
for l in L: by[int(l['regle_idx'])].append(l)
def montre(idx, statuts=('discordant','nul_pertinent'), maxn=8, conc=0):
    r=[x for x in R if int(x['regle_idx'])==idx][0]
    print(f"\n### idx{idx} {r['gene']} | {r['medicament']} | {r['etat_regle']} | {r['action']} | {r['source']} | dose={r['dose_regle']} | cand={r['n_lignes_candidates']} C={r['n_pmid_concordants']} X={r['n_pmid_contre']} -> {r['verdict_auto']}")
    seen=set(); n=0
    for l in by[idx]:
        if l['statut'] in statuts and (l['pmid'],l['statut']) not in seen:
            seen.add((l['pmid'],l['statut'])); n+=1
            if n<=maxn: print(f"  [{l['statut'][:4]}|{l['type']}|{l['classe_sujet']}|{l['direction'][:3]}] PMID {l['pmid']}: {l['phrase'][:210]}")
    c=0
    for l in by[idx]:
        if l['statut']=='concordant' and c<conc:
            c+=1; print(f"  [CONC|{l['type']}|{l['classe_sujet']}|{l['direction'][:3]}] PMID {l['pmid']}: {l['phrase'][:210]}")
if __name__=='__main__':
    ids=[int(x) for x in sys.argv[2:]]
    montre_args={'conc':int(sys.argv[1])}
    for i in ids: montre(i,**montre_args)
