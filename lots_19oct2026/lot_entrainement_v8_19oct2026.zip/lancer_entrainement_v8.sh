#!/bin/bash
# Entraînement complet sur le corpus v4, protocole v8 (même découpage pour les trois modèles). Ne modifie aucun fichier v7.
cd /mnt/user-data/outputs
D=corpus_v4/phenotype_drug_dataset_v4.csv
F=/home/claude/drug_fingerprints_v2.pkl
python3 train_arbres_v8.py --data $D --fp $F --out resultats_v8/xgb --modele xgb --threads 2 > resultats_v8/xgb_sortie.txt 2>&1
python3 train_arbres_v8.py --data $D --fp $F --out resultats_v8/rf  --modele rf  --threads 2 > resultats_v8/rf_sortie.txt 2>&1
python3 train_dl_v8.py --data $D --fp $F --out resultats_v8/dl_film --variante film > resultats_v8/dl_film_sortie.txt 2>&1
echo FIN > resultats_v8/FIN.txt
