#!/usr/bin/env python3
"""
Validation externe v1.1 (amendée le 8 nov. 2026, voir AMENDEMENT_1_v1_1.md) : recommandations de l'application (règles v14, alertes)
contre les études publiées annotées dans ClinPGx (var_drug_ann + var_pheno_ann).

Les règles d'appariement et de concordance sont celles du protocole
PROTOCOLE_validation_externe_v1.md (empreinte figée AVANT tout calcul de verdict).
Aucune valeur n'est choisie après avoir vu un résultat.

Usage:
  python3 -I validation_externe_v1.py --tests
  python3 -I validation_externe_v1.py DATA_DIR ALLELE_TABLE.csv OUT_DIR
"""
import csv, re, sys, os, collections, json, hashlib

# ----------------------------------------------------------------------------
# 1. Fonction des allèles (PyPGx 0.27.0) -> R2 (aucune fonction), R1 (diminuée), N, A, U
# ----------------------------------------------------------------------------
def charger_alleles(chemin):
    T = {}
    for t in csv.DictReader(open(chemin, encoding='utf-8')):
        f = t['Function']
        c = {'No Function': 'R2', 'Decreased Function': 'R1', 'Normal Function': 'N',
             'Increased Function': 'A'}.get(f, 'U')
        T[(t['Gene'], t['StarAllele'])] = c
    return T

RE_STAR = re.compile(r'\*\d+[A-Za-z]*(?:x(?:N|\d+))?')
RE_DUP = re.compile(r'x(?:N|\d+)$')

def fonction_allele(T, gene, tok):
    if RE_DUP.search(tok):
        base = RE_DUP.sub('', tok)
        fb = T.get((gene, base), 'U')
        return 'A' if fb == 'N' else 'U'          # duplication d'un allèle normal = fonction augmentée
    return T.get((gene, tok), 'U')

# ----------------------------------------------------------------------------
# 2. Classe du sujet / du comparateur d'une étude
#    PM_like, IM_like, REDUIT_GEN, RM_like, UM_like, AUGMENTE_GEN, NORMAL, INCONNU, VIDE
# ----------------------------------------------------------------------------
def classe_metaboliseur(txt):
    t = (txt or '').strip().lower()
    if not t:
        return 'VIDE'
    morceaux = [m.strip() for m in re.split(r'\band\b|,|/|\bor\b', t) if m.strip()]
    cl = set()
    for m in morceaux:
        if 'ultrarapid' in m or 'ultra-rapid' in m:
            cl.add('UM_like')
        elif 'rapid' in m or 'high activity' in m or 'increased function' in m:
            cl.add('RM_like' if 'rapid' in m else 'AUGMENTE_GEN')
        elif 'poor' in m or 'slow' in m:
            cl.add('PM_like')
        elif 'intermediate' in m:
            cl.add('IM_like')
        elif 'low activity' in m or 'deficien' in m or 'decreased function' in m or 'reduced' in m:
            cl.add('REDUIT_GEN')
        elif 'normal' in m or 'extensive' in m:
            cl.add('NORMAL')
        else:
            cl.add('INCONNU')
    return fusion(cl)

def fusion(cl):
    cl = set(cl)
    if len(cl) == 1:
        return next(iter(cl))
    if 'INCONNU' in cl or 'NORMAL' in cl:
        return 'INCONNU'
    if cl <= {'PM_like', 'IM_like', 'REDUIT_GEN'}:
        return 'REDUIT_GEN'
    if cl <= {'RM_like', 'UM_like', 'AUGMENTE_GEN'}:
        return 'AUGMENTE_GEN'
    return 'INCONNU'

def classe_alleles(T, gene, txt):
    t = (txt or '').strip()
    if not t:
        return 'VIDE'
    groupes = [g.strip() for g in re.split(r'\+|,|\bor\b', t) if g.strip()]
    cl = set()
    for g in groupes:
        toks = RE_STAR.findall(g)
        if not toks:
            cl.add('INCONNU'); continue
        fs = [fonction_allele(T, gene, k) for k in toks]
        if 'U' in fs:
            cl.add('INCONNU'); continue
        if len(toks) >= 2:                       # diplotype
            if fs.count('R2') == len(fs):
                cl.add('PM_like')
            elif sorted(fs) == ['N', 'R2']:          # AMENDEMENT v1.1 (A1) : hétérozygote sans fonction = IM_like
                cl.add('IM_like')
            elif any(f in ('R1', 'R2') for f in fs) and 'A' not in fs:
                cl.add('REDUIT_GEN')
            elif any(f in ('R1', 'R2') for f in fs) and 'A' in fs:
                cl.add('INCONNU')
            elif 'A' in fs:
                cl.add('AUGMENTE_GEN')
            else:
                cl.add('NORMAL')
        else:                                    # allèle isolé
            f = fs[0]
            cl.add({'R2': 'REDUIT_GEN', 'R1': 'REDUIT_GEN', 'N': 'NORMAL', 'A': 'AUGMENTE_GEN'}[f])
    return fusion(cl)

def classe_genotype(T, gene, metab, alleles):
    c = classe_metaboliseur(metab)
    if c != 'VIDE':
        return c, 'metaboliseur'
    c = classe_alleles(T, gene, alleles)
    if c != 'VIDE':
        return c, 'alleles'
    return 'VIDE', ''

FAM_RED = {'PM_like', 'IM_like', 'REDUIT_GEN'}
FAM_AUG = {'RM_like', 'UM_like', 'AUGMENTE_GEN'}

def sujet_effectif(sujet, comp):
    """Retourne (classe_effective, signe) ; signe -1 si l'étude compare un sujet normal
    à un comparateur réduit/augmenté (la direction doit être inversée)."""
    if sujet in ('VIDE', 'INCONNU'):
        return 'INCONNU', 0
    if sujet == 'NORMAL':
        if comp in FAM_RED | FAM_AUG:
            return comp, -1
        return 'NORMAL', 0
    if comp in ('VIDE', 'NORMAL'):
        return sujet, +1
    return 'INCONNU', 0                           # comparaison interne (ex. PM vs IM) : exclue

# ----------------------------------------------------------------------------
# 3. Classe de la règle de l'application
# ----------------------------------------------------------------------------
MANUEL_ONLY = {'F5', 'G6PD', 'CYP3A5'}

def etat_regle(gene, valeur):
    if gene.startswith('HLA-'):
        return 'PORTEUR'
    if gene in MANUEL_ONLY:
        return 'MANUEL'
    v = float(valeur)
    if v == 0.0: return 'PM'
    if v in (0.25, 0.5, 0.75): return 'IM'
    if v == 1.5: return 'RM'
    if v == 2.0: return 'UM'
    return 'MANUEL'

def etat_compatible(etat, classe):
    if etat == 'PM': return classe in ('PM_like', 'REDUIT_GEN')
    if etat == 'IM': return classe in ('IM_like', 'REDUIT_GEN')
    if etat == 'RM': return classe in ('RM_like', 'AUGMENTE_GEN')
    if etat == 'UM': return classe in ('UM_like', 'AUGMENTE_GEN')
    return False

def sens_dose(texte):
    t = (texte or '').lower()
    down = up = False
    for m in re.finditer(r'(\d{1,3})\s*%\s*(?:de la|of|de)\b[^.]{0,40}dos', t):
        n = int(m.group(1))
        if n < 100: down = True
        elif n > 100: up = True
    if re.search(r'(reduc|decreas|lower|diminu|réduir|réduct|halv|moitié)\w*[^.]{0,60}dos|dos\w*[^.]{0,60}(reduc|decreas|lower|diminu|réduit)', t):
        down = True
    if re.search(r'(increas|higher|greater|augment)\w*[^.]{0,60}dos|dos\w*[^.]{0,60}(increas|higher|augment)', t):
        up = True
    if down and not up: return 'DOWN'
    if up and not down: return 'UP'
    return 'NA'

# ----------------------------------------------------------------------------
# 4. Médicament
# ----------------------------------------------------------------------------
def med_hit(regle_med, drugs_field):
    d = ', ' + (drugs_field or '').lower() + ', '
    r = regle_med.lower().strip()
    if ', ' + r + ', ' in d:
        return 'exact'
    if ' / ' in r or ' and ' in r:
        for c in re.split(r' / | and ', r):
            if ', ' + c.strip() + ', ' in d:
                return 'composant'
    return None

# ----------------------------------------------------------------------------
# 5. Type de résultat d'une ligne d'étude
# ----------------------------------------------------------------------------
TERMES_EXPO = {'concentrations of', 'exposure to', 'dose-adjusted trough concentrations of',
               'trough concentration of', 'steady-state concentration of', 'half-life time of'}
TERMES_CLEAR = {'clearance of', 'metabolism of'}
TERMES_EFF = {'response to', 'clinical benefit to'}

def type_resultat(ligne, origine):
    cats = [c.strip() for c in ligne['Phenotype Category'].split(',')]
    if origine == 'pheno':
        if 'Toxicity' in cats:
            return 'TOX', ''
        return 'AUTRE', ''
    terme = ligne.get('PD/PK terms', '').strip()
    if terme == 'dose of': return 'DOSE', terme
    if terme in TERMES_EXPO or terme in TERMES_CLEAR: return 'PK', terme
    if terme in TERMES_EFF: return 'EFF', terme
    if terme == 'resistance to': return 'EFF_INV', terme
    return 'AUTRE', terme

def orienter(typ, terme, direction, signe, dose_regle):
    """Retourne 'conc', 'disc' ou 'nonor' pour une association significative."""
    if direction not in ('increased', 'decreased') or signe == 0:
        return 'nonor'
    d = direction
    if signe == -1:
        d = 'decreased' if d == 'increased' else 'increased'
    if typ == 'TOX':
        return 'conc' if d == 'increased' else 'disc'
    if typ == 'EFF':
        return 'conc' if d == 'decreased' else 'nonor'
    if typ == 'EFF_INV':
        return 'conc' if d == 'increased' else 'nonor'
    if typ == 'DOSE':
        if dose_regle == 'NA': return 'nonor'
        etude = 'UP' if d == 'increased' else 'DOWN'
        return 'conc' if etude == dose_regle else 'disc'
    if typ == 'PK':
        if dose_regle == 'NA': return 'nonor'
        if terme in TERMES_EXPO: expo = 'UP' if d == 'increased' else 'DOWN'
        else: expo = 'DOWN' if d == 'increased' else 'UP'   # clairance/métabolisme
        attendu = 'UP' if dose_regle == 'DOWN' else 'DOWN'    # dose réduite <-> exposition plus haute
        return 'conc' if expo == attendu else 'disc'
    return 'nonor'

def nul_pertinent(typ, dose_regle):
    if typ in ('TOX', 'EFF', 'EFF_INV'): return True
    if typ in ('DOSE', 'PK'): return dose_regle != 'NA'
    return False

# ----------------------------------------------------------------------------
# 6. Verdict d'une règle
# ----------------------------------------------------------------------------
def verdict(C, X, signal, n_cand, n_etat_ok, n_classables):
    if n_cand == 0: return 'AUCUNE_ETUDE'
    if C and not (X - C): return 'SOUTENUE'
    if C and (X - C): return 'MIXTE'
    if X: return 'NON_SOUTENUE'
    if signal: return 'SIGNAL_NON_ORIENTE'
    if n_classables == 0: return 'NON_CLASSABLE_AUTO'
    return 'AUTRE_PHENOTYPE'

RE_HLA = re.compile(r'HLA-[A-Z0-9]+(\*\d+:\d+(?::\d+)*)')

SENS_DOSE_MANUEL = {}

def main(data_dir, table_alleles, out_dir):
    for t in csv.DictReader(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sens_dose_manuel_v1_1.csv'), encoding='utf-8')):
        SENS_DOSE_MANUEL[int(t['regle_idx'])] = t['sens_dose']
    T = charger_alleles(table_alleles)
    regles = list(csv.DictReader(open(os.path.join(data_dir, 'regles_v14_monogene.csv'), encoding='utf-8')))
    base = os.path.join(data_dir, 'clinpgx_nov2026', 'variantAnnotations')
    L = []
    for origine, f in (('drug', 'var_drug_ann.tsv'), ('pheno', 'var_pheno_ann.tsv')):
        for l in csv.DictReader(open(os.path.join(base, f), encoding='utf-8'), delimiter='\t'):
            l['_origine'] = origine
            L.append(l)
    par_gene = collections.defaultdict(list)
    for l in L:
        par_gene[l['Gene']].append(l)

    alertes = [(i, r) for i, r in enumerate(regles) if r['action'] != 'STANDARD']
    lignes_out, regles_out = [], []
    for i, r in alertes:
        gene = r['gene']
        etat = etat_regle(gene, r['valeur'])
        dose = SENS_DOSE_MANUEL.get(i, 'NA')          # AMENDEMENT v1.1 (A2) : table lue à la main
        cible_hla = None
        gene_etude = gene
        if gene.startswith('HLA-'):
            m = re.match(r'(HLA-[A-Z0-9]+)(\*.+)$', gene)
            gene_etude, cible_hla = m.group(1), m.group(2)
        C, X, S, DOUT = set(), set(), set(), set()
        n_cand = n_etat_ok = n_classables = 0
        ex_conc, ex_contre = [], []
        for l in par_gene.get(gene_etude, []):
            mh = med_hit(r['medicament'], l['Drug(s)'])
            if not mh: continue
            n_cand += 1
            # classe du sujet
            if cible_hla:
                vars_ = set(RE_HLA.findall(l['Variant/Haplotypes']))
                comp_vars = set(RE_HLA.findall(l.get('Comparison Allele(s) or Genotype(s)', '')))
                if cible_hla in vars_ and cible_hla not in comp_vars:
                    classe, signe, src = 'PORTEUR', +1, 'variante_hla'
                else:
                    classe, signe, src = 'INCONNU', 0, 'hla_autre'
            else:
                sc, src = classe_genotype(T, gene, l['Metabolizer types'], l['Alleles'])
                cc, _ = classe_genotype(T, gene, l['Comparison Metabolizer types'],
                                         l['Comparison Allele(s) or Genotype(s)'])
                classe, signe = sujet_effectif(sc, cc if cc != 'VIDE' else 'VIDE')
            classable = classe not in ('INCONNU', 'VIDE', 'NORMAL')
            if classable: n_classables += 1
            ok = (classe == 'PORTEUR') if cible_hla else (etat in ('PM', 'IM', 'RM', 'UM') and etat_compatible(etat, classe))
            if ok: n_etat_ok += 1
            typ, terme = type_resultat(l, l['_origine'])
            assoc = l['Is/Is Not associated']; sig = l['Significance']
            if assoc == 'Associated with' and sig == 'yes': res = 'positif'
            elif assoc == 'Associated with': res = 'douteux'
            else: res = 'nul'
            statut = ''
            pmid = l['PMID']
            if ok:
                if res == 'positif':
                    o = orienter(typ, terme, l['Direction of effect'], signe, dose)
                    if o == 'conc': C.add(pmid); statut = 'concordant'
                    elif o == 'disc': X.add(pmid); statut = 'discordant'
                    else: S.add(pmid); statut = 'signal_non_oriente'
                elif res == 'nul':
                    if nul_pertinent(typ, dose): X.add(pmid); statut = 'nul_pertinent'
                    else: statut = 'nul_non_pertinent'
                else:
                    DOUT.add(pmid); statut = 'douteux'
            else:
                statut = 'etat_non_apparie' if classable else 'non_classable'
            if statut == 'concordant' and len(ex_conc) < 3: ex_conc.append(f"{pmid}: {l['Sentence'][:160]}")
            if statut in ('discordant', 'nul_pertinent') and len(ex_contre) < 3: ex_contre.append(f"{pmid}: {l['Sentence'][:160]}")
            lignes_out.append({'regle_idx': i, 'gene': gene, 'etat_regle': etat, 'medicament_regle': r['medicament'],
                               'action': r['action'], 'dose_regle': dose, 'ligne_id': l['Variant Annotation ID'],
                               'origine': l['_origine'], 'pmid': pmid, 'match_med': mh, 'classe_sujet': classe,
                               'source_classe': src, 'signe': signe, 'type': typ, 'terme': terme,
                               'resultat': res, 'direction': l['Direction of effect'], 'statut': statut,
                               'phrase': l['Sentence']})
        v = verdict(C, X, S, n_cand, n_etat_ok, n_classables) if etat != 'MANUEL' else (
            'AUCUNE_ETUDE' if n_cand == 0 else 'A_LIRE_A_LA_MAIN')
        regles_out.append({'regle_idx': i, 'gene': gene, 'valeur': r['valeur'], 'etat_regle': etat,
                           'phenotype': r['phenotype'], 'medicament': r['medicament'], 'action': r['action'],
                           'source': r['source'], 'dose_regle': dose, 'n_lignes_candidates': n_cand,
                           'n_lignes_classables': n_classables, 'n_lignes_etat_apparie': n_etat_ok,
                           'n_pmid_concordants': len(C), 'n_pmid_contre': len(X - C), 'n_pmid_les_deux': len(C & X),
                           'n_pmid_signal': len(S - C - X), 'n_pmid_douteux': len(DOUT - C - X - S),
                           'part_concordante_desc': (round(len(C) / len(C | X), 3) if (C | X) else ''), 'verdict_auto': v, 'pmid_concordants': ';'.join(sorted(C)),
                           'pmid_contre': ';'.join(sorted(X)), 'exemples_concordants': ' || '.join(ex_conc),
                           'exemples_contre': ' || '.join(ex_contre)})
    os.makedirs(out_dir, exist_ok=True)
    def ecrire(nom, rows):
        with open(os.path.join(out_dir, nom), 'w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    ecrire('verdict_par_regle_auto_v1.csv', regles_out)
    ecrire('lignes_etudes_appariees_v1.csv', lignes_out)
    print('regles_alerte', len(regles_out), 'lignes_appariees', len(lignes_out))

# ----------------------------------------------------------------------------
def tests(table_alleles):
    T = charger_alleles(table_alleles)
    assert classe_metaboliseur('poor metabolizer') == 'PM_like'
    assert classe_metaboliseur('intermediate metabolizer and poor metabolizer') == 'REDUIT_GEN'
    assert classe_metaboliseur('normal metabolizer and intermediate metabolizer') == 'INCONNU'
    assert classe_metaboliseur('ultrarapid metabolizer') == 'UM_like'
    assert classe_metaboliseur('slow acetylator') == 'PM_like'
    assert classe_alleles(T, 'CYP2D6', '*4/*4') == 'PM_like'
    assert classe_alleles(T, 'CYP2D6', '*1/*4') == 'IM_like'
    assert classe_alleles(T, 'CYP2D6', '*1/*1') == 'NORMAL'
    assert classe_alleles(T, 'CYP2C9', '*3') == 'REDUIT_GEN'
    assert classe_alleles(T, 'CYP2D6', 'TT') == 'INCONNU'
    assert sujet_effectif('NORMAL', 'REDUIT_GEN') == ('REDUIT_GEN', -1)
    assert sujet_effectif('REDUIT_GEN', 'VIDE') == ('REDUIT_GEN', +1)
    assert sujet_effectif('PM_like', 'IM_like') == ('INCONNU', 0)
    assert sens_dose('Reduce starting dose to 750 mg/m2 in poor metabolizers') == 'DOWN'
    assert sens_dose('Initiate 50% of starting dose') == 'DOWN'
    assert sens_dose('Increase starting daily dose by 100%') == 'UP'
    assert sens_dose('Avoid standard dose clopidogrel. Use prasugrel') == 'NA'
    assert med_hit('simvastatin', 'atorvastatin, simvastatin') == 'exact'
    assert med_hit('simvastatin', 'simvastatin acid') is None
    assert med_hit('lidocaine / prilocaine', 'lidocaine') == 'composant'
    assert orienter('TOX', '', 'increased', +1, 'NA') == 'conc'
    assert orienter('TOX', '', 'decreased', -1, 'NA') == 'conc'
    assert orienter('DOSE', 'dose of', 'decreased', +1, 'DOWN') == 'conc'
    assert orienter('DOSE', 'dose of', 'increased', +1, 'DOWN') == 'disc'
    assert orienter('PK', 'concentrations of', 'increased', +1, 'DOWN') == 'conc'
    assert orienter('PK', 'clearance of', 'decreased', +1, 'DOWN') == 'conc'
    assert orienter('PK', 'concentrations of', 'increased', +1, 'NA') == 'nonor'
    assert orienter('EFF', 'response to', 'increased', +1, 'NA') == 'nonor'
    print('tests unitaires: OK')

if __name__ == '__main__':
    if len(sys.argv) >= 2 and sys.argv[1] == '--tests':
        tests(sys.argv[2] if len(sys.argv) > 2 else 'allele_table_pypgx_0_27_0.csv')
    else:
        main(sys.argv[1], sys.argv[2], sys.argv[3])
