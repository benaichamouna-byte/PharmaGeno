#!/usr/bin/env python3
"""
construire_regles_v3_candidates_v1.py : assemble les règles CANDIDATES gène -> médicament -> action pour G6PD, HLA, MT-RNR1 et RYR1/CACNA1S,
à partir des lectures déjà faites (g6pd_consignes_v2.csv, hla_consignes_v2.csv) et des JSON PharmGKB (MT-RNR1 : PA166229081 ; RYR1/CACNA1S : PA166303941).
N'écrase rien : regles_v2_* restent intacts. Rien n'est fusionné : tout est "candidate, à valider".
Classes d'action : EVITER / SURVEILLER / STANDARD / NON_DETERMINE (génotype ou activité à obtenir) / AUCUNE_RECOMMANDATION / A_VALIDER (lecture à confirmer).
Génotype non connu pour un profil -> NON_DETERMINE (jamais STANDARD).
Usage : python3 construire_regles_v3_candidates_v1.py --ga DOSSIER_JSON --g6pd g6pd_consignes_v2.csv --hla hla_consignes_v2.csv --sortie regles_v3_candidates_v1.csv
"""
import argparse, json, os, re
import pandas as pd

LIEN = 'https://www.pharmgkb.org/guidelineAnnotation/'
G6 = {'EVITER': 'EVITER', 'EVITER_SAUF_SCHEMAS_PALUDISME': 'EVITER', 'SURVEILLER': 'SURVEILLER', 'PAS_D_ACTION': 'STANDARD', 'AUCUNE_RECOMMANDATION': 'AUCUNE_RECOMMANDATION'}
HL = {'CONTRE_INDIQUE': 'EVITER', 'EVITER': 'EVITER', 'EVITER_ALTERNATIVE': 'EVITER', 'EVITER_SI_POSSIBLE': 'EVITER', 'EVITER_SI_ALTERNATIVE': 'EVITER',
      'SURVEILLER': 'SURVEILLER', 'AUCUNE_RECOMMANDATION': 'AUCUNE_RECOMMANDATION'}  # le reste -> A_VALIDER


def ligne(gene, ph, med, brut, classe, org, force, cond, gid, statut):
    return dict(gene=gene, phenotype_ou_allele=ph, medicament=med, action_brute=brut, action_classe_proposee=classe, organisme=org, force=force,
                condition=cond, statut='candidate, à valider', statut_lecture=statut, id_guideline=gid, lien_pharmgkb=LIEN + str(gid))


def g6pd(path):
    d = pd.read_csv(path).fillna(''); L = []
    for _, r in d.iterrows():
        cat = r.categorie_risque_cpic; none = cat == 'AUCUNE_RECOMMANDATION'; haut = cat.startswith('HAUT'); moy = cat == 'RISQUE_MOYEN'
        c = r.note; st = r.statut_lecture; f = r.force_article_tableau2
        def add(ph, brut, cl, force, cond=''): L.append(ligne('G6PD', ph, r.medicament, brut, cl, 'CPIC', force, (cond + ' ' + c).strip(), r.id_guideline, st))
        add('Normal', 'AUCUNE_RECOMMANDATION' if none else 'STANDARD', 'AUCUNE_RECOMMANDATION' if none else 'STANDARD', '' if none else 'Strong')
        add('Deficient', r.action_deficient, G6[r.action_deficient], f)
        add('Deficient avec CNSHA', r.action_deficient_CNSHA, G6[r.action_deficient_CNSHA], r.force_CNSHA)
        if none: add('Variable', 'AUCUNE_RECOMMANDATION', 'AUCUNE_RECOMMANDATION', ''); add('Indéterminé', 'AUCUNE_RECOMMANDATION', 'AUCUNE_RECOMMANDATION', '')
        else:
            if haut or moy: add('Variable', 'MESURER_ACTIVITE_ENZYMATIQUE', 'NON_DETERMINE', 'Moderate', 'Activité G6PD à mesurer (mosaïcisme X chez les femmes hétérozygotes).')
            else: add('Variable', 'STANDARD', 'STANDARD', 'Moderate', 'Pas de raison d\'éviter aux doses standard.')
            add('Indéterminé', 'MESURER_ACTIVITE_ENZYMATIQUE', 'NON_DETERMINE', 'Moderate', 'Activité G6PD à mesurer.')
    return L


def hla(path):
    d = pd.read_csv(path).fillna(''); L = []
    for _, r in d.iterrows():
        L.append(ligne('HLA', 'porteur ' + r.alleles, r.medicament, r.action_provisoire, HL.get(r.action_provisoire, 'A_VALIDER'), r.organisme, r.force_lue, r.condition_ou_precision, r.id_guideline, r.statut_lecture))
    L.append(ligne('HLA', 'non porteur HLA-B*15:02 / HLA-A*31:01', 'carbamazepine', 'STANDARD', 'STANDARD', 'CPIC', 'Strong', 'Dose standard ; un test négatif n\'élimine pas le risque.', 'PA166105008', 'texte complet lu (partiel)'))
    return L


def jsonrows(ga, gid, gene, defs, drugs_note=''):
    G = json.load(open(os.path.join(ga, gid + '.json'), encoding='utf-8'))['guideline']; L = []
    for c in G['relatedChemicals']:
        m = re.sub(r'\s+', ' ', c['name'].strip().lower())
        for ph, brut, cl, force, cond in defs:
            L.append(ligne(gene, ph, m, brut, cl, G['source'], force, cond, gid, 'texte complet lu (tableau 1)' if gene == 'MT-RNR1' else 'résumé et extraits lus ; tableau de recommandations et force non lus'))
    return L


def main():
    ap = argparse.ArgumentParser()
    for k in ('ga', 'g6pd', 'hla', 'sortie'): ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    mt = [('risque accru (m.1095T>C, m.1494C>T, m.1555A>G)', 'EVITER', 'EVITER', 'Strong', 'Sauf si le risque de surdité est justifié par la gravité de l\'infection et l\'absence d\'alternative ; sinon surveillance auditive fréquente, dose et durée minimales.'),
          ('risque normal (aucun variant à risque ou m.827A>G)', 'STANDARD', 'STANDARD', 'Strong', 'Dose standard, courte durée, suivi des concentrations ; l\'absence de variant ne supprime pas le risque.'),
          ('risque incertain (20 variants listés)', 'STANDARD_AVEC_SURVEILLANCE', 'SURVEILLER', 'Optional', 'Dose standard, courte durée, suivi des concentrations et audition.'),
          ('génotype MT-RNR1 non connu', 'NON_DETERMINE', 'NON_DETERMINE', '', 'Ne jamais traiter comme normal.')]
    ry = [('variant pathogène RYR1 ou CACNA1S (susceptibilité à l\'hyperthermie maligne)', 'RELATIVEMENT_CONTRE_INDIQUE', 'EVITER', 'non lue', 'Résumé CPIC : relativement contre-indiqué.'),
          ('résultat négatif ou variant non listé', 'SUSCEPTIBILITE_INCERTAINE', 'NON_DETERMINE', 'non lue', 'Texte CPIC : un résultat négatif n\'élimine pas la susceptibilité.'),
          ('génotype RYR1/CACNA1S non connu', 'NON_DETERMINE', 'NON_DETERMINE', '', 'Ne jamais traiter comme normal.')]
    L = g6pd(a.g6pd) + hla(a.hla) + jsonrows(a.ga, 'PA166229081', 'MT-RNR1', mt) + jsonrows(a.ga, 'PA166303941', 'RYR1/CACNA1S', ry)
    out = pd.DataFrame(L)
    out.to_csv(a.sortie, index=False)
    print(len(out), 'règles candidates,', out.medicament.nunique(), 'médicaments ->', a.sortie)
    print(out.groupby('gene').agg(regles=('medicament', 'size'), medicaments=('medicament', 'nunique')).to_string())
    print(out.action_classe_proposee.value_counts().to_string())


if __name__ == '__main__':
    main()
