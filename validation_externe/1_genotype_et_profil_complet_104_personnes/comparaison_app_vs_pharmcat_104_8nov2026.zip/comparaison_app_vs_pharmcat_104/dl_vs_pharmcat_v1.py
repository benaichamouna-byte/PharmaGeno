"""dl_vs_pharmcat_v1.py (8 nov. 2026, 21h58) : le DL (action_dl) donne-t-il l'action que PharmCAT soutient ?
Unité : personne x médicament dont TOUTES les règles CPIC/DPWG de l'application avec contenu sont RETROUVEE (ou équivalent manuel) chez PharmCAT (agreger_reco_v1_1)
 ET dont l'action finale de la règle (action_cpic) est égale à la plus sévère de ces règles (donc l'action finale est portée par un texte PharmCAT).
Mesure : action_dl == action_cpic. Sévérité : STANDARD < SURVEILLER < ADAPTER_DOSE < EVITER. Défini avant calcul ; aucun autre filtre."""
import csv, json, os, collections
SC='/tmp/claude-0/-home-claude/8409b04b-17f7-52aa-bb79-1c3b814505b7/scratchpad/'
SEV={'STANDARD':0,'SURVEILLER':1,'ADAPTER_DOSE':2,'EVITER':3}
A1=collections.defaultdict(list)
for r in csv.DictReader(open('resultat/detail_A1_centre_app_104.csv')): A1[(r['personne'],r['medicament'])].append(r['statut'])
def app(s):
    for d in ('app104_a','app104_b'):
        p=SC+f'recocmp/{d}/sortie_{s}.json'
        if os.path.exists(p): return json.load(open(p))
tot=ok=0; dis=collections.Counter(); matrice=collections.Counter(); rows=[]
for s in [l.strip() for l in open(SC+'getrm/liste_104_gelee.txt') if l.strip()]:
    for e in app(s)['moteur']:
        med=e['medicament'].lower(); st=A1.get((s,med))
        if not st or any(x not in ('RETROUVEE','RETROUVEE_EQUIV_MANUELLE') for x in st): continue
        rs=[r for r in e['regle_cpic'] if r['source'] in ('CPIC','DPWG')]
        if not rs or e.get('action_cpic') is None or e.get('action_dl') is None: continue
        mx=max(rs,key=lambda r:SEV[r['action']])['action']
        if mx!=e['action_cpic']: continue
        tot+=1; matrice[(e['action_cpic'],e['action_dl'])]+=1
        if e['action_dl']==e['action_cpic']: ok+=1
        else: dis[med]+=1; rows.append((s,med,e['action_cpic'],e['action_dl'],round(e.get('confiance_dl') or 0,3)))
print('unités',tot,'| DL = action soutenue par PharmCAT :',ok,'| %.2f %%'%(100*ok/tot))
print('désaccords',tot-ok,'sur',len(dis),'médicaments :',dis.most_common(10))
print(sorted(matrice.items(),key=lambda x:-x[1])[:12])
csv.writer(open('resultat/desaccords_DL_vs_PharmCAT_104.csv','w',newline='')).writerows([('personne','medicament','action_regle_soutenue_PharmCAT','action_DL','confiance_DL')]+rows)
