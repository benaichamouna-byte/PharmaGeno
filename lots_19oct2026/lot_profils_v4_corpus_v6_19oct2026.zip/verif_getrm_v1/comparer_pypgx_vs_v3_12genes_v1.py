"""
comparer_pypgx_vs_v3_12genes_v1.py : pour chaque gène d'origine recalculé avec PyPGx 0.27.0 (pgxrun/<GENE>/phenotypes.zip) sur les 1 379 profils,
compare le phénotype PyPGx (codé avec codage_pypgx_valeur_v7.csv) à la valeur du profil actuel (profils_genes_v3.csv, reprise du corpus v3),
puis, pour les échantillons présents dans GeT-RM, compare chacune des deux versions au phénotype CPIC déduit du consensus GeT-RM
(détail produit par comparer_12genes_getrm_v1.py : comparaison_12genes_getrm_v1_detail.csv).
Aucune valeur n'est modifiée ici : ce script ne fait que mesurer.
Usage : python3 comparer_pypgx_vs_v3_12genes_v1.py --pgxrun pgxrun --profils profils_genes_v3.csv --codage codage_pypgx_valeur_v7.csv --getrm_detail comparaison_12genes_getrm_v1_detail.csv --sortie DOSSIER
"""
import argparse, os, zipfile
import numpy as np, pandas as pd

GENES = ['NUDT15', 'TPMT', 'CYP2C19', 'CYP2C9', 'CYP2B6', 'CYP3A5', 'DPYD', 'SLCO1B1', 'UGT1A1', 'ABCG2', 'F5']

def lire(run, g):
    z = zipfile.ZipFile(os.path.join(run, g, 'phenotypes.zip'))
    d = pd.read_csv(z.open([x for x in z.namelist() if x.endswith('data.tsv')][0]), sep='\t', index_col=0)
    return d.iloc[:, 0]

def main():
    ap = argparse.ArgumentParser()
    for k in ('pgxrun', 'profils', 'codage', 'getrm_detail', 'sortie'): ap.add_argument('--' + k, required=True)
    a = ap.parse_args(); os.makedirs(a.sortie, exist_ok=True)
    P = pd.read_csv(a.profils).set_index('sample_id')
    cod = pd.read_csv(a.codage).set_index('phenotype_pypgx')['valeur'].to_dict()
    ref = pd.read_csv(a.getrm_detail)
    res, det = [], []
    for g in GENES:
        if not os.path.exists(os.path.join(a.pgxrun, g, 'phenotypes.zip')): print('absent :', g); continue
        ph = lire(a.pgxrun, g).reindex(P.index)
        neuf = ph.map(lambda s: cod.get(s, np.nan) if isinstance(s, str) else np.nan)
        ancien = P[g]
        same = (neuf.fillna(-9) == ancien.fillna(-9))
        indet = int((ph == 'Indeterminate').sum()); inconnu = int(ph.map(lambda s: isinstance(s, str) and s not in cod).sum())
        res.append(dict(gene=g, profils=len(P), identiques=int(same.sum()), differents=int((~same).sum()), pypgx_indetermine=indet, phenotype_hors_codage=inconnu))
        x = pd.DataFrame(dict(gene=g, sample_id=P.index, phenotype_pypgx=ph.values, valeur_v3=ancien.values, valeur_pypgx=neuf.values))
        det.append(x[~same.values])
        print('\n==', g, '| profils différents :', int((~same).sum())); print(pd.crosstab(ancien.fillna(-9), neuf.fillna(-9), rownames=['v3'], colnames=['PyPGx']).to_string())
        r = ref[(ref.gene == g) & ref.statut.isin(['accord', 'ambigu_accepte', 'desaccord'])]
        if len(r):
            v = r.valeur_getrm.astype(str).str.split('|').str[0].astype(float)
            ok_v3 = int((r.valeur_profil.values == v.values).sum())
            ok_new = int((neuf.reindex(r.sample_id).fillna(-9).values == v.values).sum())
            print(f'  vs GeT-RM (n={len(r)}) : accord v3 = {ok_v3} | accord PyPGx = {ok_new}')
    pd.DataFrame(res).to_csv(os.path.join(a.sortie, 'pypgx_vs_v3_12genes_v1_resume.csv'), index=False)
    pd.concat(det).to_csv(os.path.join(a.sortie, 'pypgx_vs_v3_12genes_v1_profils_differents.csv'), index=False)
    print('\n', pd.DataFrame(res).to_string(index=False))

if __name__ == '__main__':
    main()
