"""
calculer_phenotypes_cpic_12genes_v1.py : phénotype des gènes d'origine = génotype PyPGx 0.27.0 (pgxrun/<GENE>/genotypes.zip) -> table CPIC distribuée dans le dépôt PharmCAT
(phenotype/<GENE>.json, clé = comptage des allèles) -> codage du projet (codage_pypgx_valeur_v7.csv). Même méthode que pour NAT2, CYP3A4, RYR1, CACNA1S et CFTR.
Pourquoi : PyPGx rend « Indeterminate » pour des allèles de fonction incertaine dans SA table (ex. NUDT15 *6, TPMT *16) ; la v3 avait mis ces profils à « normal » (1.0) ;
la table CPIC donne un phénotype pour ces allèles. Un diplotype absent de la table CPIC, ou « Indeterminate » dans la table CPIC, reste MANQUANT (jamais « normal »).
Compare ensuite à la valeur du profil actuel (profils_genes_v3.csv) et, pour les échantillons GeT-RM, au phénotype CPIC déduit du consensus GeT-RM.
Usage : python3 calculer_phenotypes_cpic_12genes_v1.py --pgxrun pgxrun --profils profils_genes_v3.csv --phenodir DOSSIER_PHENOTYPE_PHARMCAT --codage codage_pypgx_valeur_v7.csv --getrm_detail comparaison_12genes_getrm_v1_detail.csv --sortie DOSSIER
"""
import argparse, json, os, zipfile
import numpy as np, pandas as pd

GENES = ['NUDT15', 'TPMT', 'CYP2C19', 'CYP2C9', 'CYP2B6', 'CYP3A5', 'DPYD', 'SLCO1B1', 'UGT1A1']   # ABCG2 et F5 : pas de table CPIC de diplotype -> phénotype dans PharmCAT

def genotypes(run, g):
    z = zipfile.ZipFile(os.path.join(run, g, 'genotypes.zip'))
    return pd.read_csv(z.open([x for x in z.namelist() if x.endswith('data.tsv')][0]), sep='\t', index_col=0).iloc[:, 0]

def table(phenodir, g):
    d = json.load(open(os.path.join(phenodir, g + '.json'), encoding='utf-8'))
    return {frozenset(x['diplotypekey'].items()): x['phenotype'] for x in d['diplotypes']}

def main():
    ap = argparse.ArgumentParser()
    for k in ('pgxrun', 'profils', 'phenodir', 'codage', 'getrm_detail', 'sortie'): ap.add_argument('--' + k, required=True)
    a = ap.parse_args(); os.makedirs(a.sortie, exist_ok=True)
    P = pd.read_csv(a.profils).set_index('sample_id')
    cod = pd.read_csv(a.codage).set_index('phenotype_pypgx')['valeur'].to_dict()
    ref = pd.read_csv(a.getrm_detail)
    out = pd.DataFrame(index=P.index); resume = []
    for g in GENES:
        if not os.path.exists(os.path.join(a.pgxrun, g, 'genotypes.zip')): print('absent :', g); continue
        gt = genotypes(a.pgxrun, g).reindex(P.index); t = table(a.phenodir, g)
        def f(s):
            if not isinstance(s, str): return (np.nan, 'genotype_absent')
            cnt = {}
            for x in s.split('/'): cnt[x] = cnt.get(x, 0) + 1
            ph = t.get(frozenset(cnt.items()))
            if ph is None: return (np.nan, 'non_mappable')
            c = cod.get(ph, np.nan)
            return (c, 'ok' if not pd.isna(c) else 'indetermine_cpic')
        r = gt.map(f); val = r.map(lambda x: x[0]); st = r.map(lambda x: x[1])
        out[g + '_genotype_pypgx'] = gt; out[g + '_valeur_cpic'] = val; out[g + '_statut'] = st
        ancien = P[g]; same = val.fillna(-9) == ancien.fillna(-9)
        print('\n==', g, '| statuts :', st.value_counts().to_dict(), '| profils différents de la v3 :', int((~same).sum()))
        print(pd.crosstab(ancien.fillna(-9), val.fillna(-9), rownames=['v3'], colnames=['PyPGx+CPIC']).to_string())
        rr = ref[(ref.gene == g) & ref.statut.isin(['accord', 'ambigu_accepte', 'desaccord'])]
        ok_v3 = ok_new = np.nan
        if len(rr):
            v = rr.valeur_getrm.astype(str).str.split('|').str[0].astype(float).values
            ok_v3 = int((rr.valeur_profil.values == v).sum()); ok_new = int((val.reindex(rr.sample_id).fillna(-9).values == v).sum())
            print(f'  vs GeT-RM (n={len(rr)}) : accord v3 = {ok_v3} | accord PyPGx+CPIC = {ok_new}')
        resume.append(dict(gene=g, profils=len(P), differents_v3=int((~same).sum()), non_mappable=int((st == 'non_mappable').sum()), indetermine_cpic=int((st == 'indetermine_cpic').sum()),
                           getrm_comparables=len(rr), accord_getrm_v3=ok_v3, accord_getrm_nouveau=ok_new))
    out.to_csv(os.path.join(a.sortie, 'phenotypes_cpic_12genes_v1.csv'))
    pd.DataFrame(resume).to_csv(os.path.join(a.sortie, 'phenotypes_cpic_12genes_v1_resume.csv'), index=False)
    print('\n', pd.DataFrame(resume).to_string(index=False))

if __name__ == '__main__':
    main()
