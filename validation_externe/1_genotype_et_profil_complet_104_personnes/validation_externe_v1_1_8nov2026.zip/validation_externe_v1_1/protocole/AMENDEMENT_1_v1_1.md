# Amendement 1 au protocole v1 — validation externe (8 novembre 2026)
Décidé APRÈS avoir calculé les verdicts v1 (empreintes v1 dans EMPREINTES_PROTOCOLE_v1.txt) et lu à la main les 23 règles « non soutenues ». Les sorties v1 sont conservées à côté, rien n'est écrasé. Le protocole v1 reste valable pour tout le reste.

Motif : la relecture des phrases a montré deux défauts de la méthode automatique v1.
- A1. Un génotype hétérozygote (un allèle sans fonction + un allèle normal, ex. NUDT15 *1/*3) était classé REDUIT_GEN et donc apparié aux règles « métaboliseur lent ». Un résultat nul chez des hétérozygotes comptait alors « contre » une règle pour métaboliseurs lents. Correction : diplotype (un sans fonction + un normal) = IM_like.
- A2. Le sens de dose de la règle (DOWN / UP / NA) était lu par expressions régulières. Exemple d'erreur : les textes statines « Prescrire ≤ 2 mg ... une dose plus haute (>2 mg) ... » étaient lus UP, ce qui fabriquait de fausses discordances. Correction : le sens de dose est lu à la main sur le seul texte de la règle (jamais sur les résultats des études) et écrit dans `sens_dose_manuel_v1_1.csv` (285 règles : 107 DOWN, 18 UP, 160 NA ; les textes conditionnels ou sans sens de dose clair sont NA).
- A3. Indicateur descriptif ajouté : part de PMID concordants parmi les PMID concordants ou « contre » (ne remplace pas le verdict).
Limite à écrire : A1 et A2 sont décidés après avoir vu les verdicts v1 ; les deux versions sont rapportées.
