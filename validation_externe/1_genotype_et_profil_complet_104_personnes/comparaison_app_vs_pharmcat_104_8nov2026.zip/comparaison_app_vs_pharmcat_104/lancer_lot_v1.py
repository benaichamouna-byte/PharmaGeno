#!/usr/bin/env python3
"""lancer_lot_v1.py (8 nov. 2026) : passe une liste de VCF individuels dans l'application v8s SANS la modifier (même chaîne que lancer_test_vcf_reel_v4.py), en chargeant l'application une seule fois.
Usage : python3 lancer_lot_v1.py LISTE.txt --vcf-dir DIR --sortie DIR [--specialite Cardiologie]"""
import os, sys, types, json, time, argparse
APP = '/home/claude/appdev/Model_v8_7_9_10/scripts'; sys.path.insert(0, APP)
import app_pharmageno_v8s as A
ap = argparse.ArgumentParser(); ap.add_argument('liste'); ap.add_argument('--vcf-dir', required=True); ap.add_argument('--sortie', required=True)
ap.add_argument('--specialite', default='Cardiologie'); ap.add_argument('--bundle', default='/root/pypgx-bundle'); ap.add_argument('--pgx-python', required=True)
a = ap.parse_args(); os.makedirs(a.sortie, exist_ok=True)
ROOT = os.path.join(APP, '..')
cfg = types.SimpleNamespace(donnees=os.path.join(ROOT, 'data'), modeles=os.path.join(ROOT, 'modeles_v10'), modeles_choix=os.path.join(ROOT, 'modeles_v10'),
    modeles_xgb=os.path.join(ROOT, 'modeles_v10x'), codage=None, tables=None, bundle=a.bundle, travail=os.path.join(a.sortie, 'travail'), pgx_python=a.pgx_python, port=5000, taille_max_mo=500)
app = A.creer_app(cfg); c = app.test_client()
for ech in [l.strip() for l in open(a.liste) if l.strip()]:
    out = os.path.join(a.sortie, 'sortie_%s.json' % ech)
    if os.path.exists(out): print('déjà fait', ech, flush=True); continue
    t0 = time.time()
    with open(os.path.join(a.vcf_dir, ech + '.vcf'), 'rb') as f:
        r = c.post('/analyser', data={'specialite': a.specialite, 'vcf': (f, ech + '.vcf'), 'echantillon': ech}, content_type='multipart/form-data')
    jid = r.headers['Location'].rstrip('/').split('/')[-1].split('?')[0]
    while True:
        e = c.get('/etat/' + jid).get_json()
        if e['etat'] in ('termine', 'erreur', 'echec', 'refuse'): break
        time.sleep(3)
    if e['etat'] == 'termine': json.dump(c.get('/json/' + jid).get_json(), open(out, 'w'), indent=1, ensure_ascii=False)
    print(ech, e['etat'], round(time.time() - t0), 's', flush=True)
print('FIN_LOT', flush=True)
