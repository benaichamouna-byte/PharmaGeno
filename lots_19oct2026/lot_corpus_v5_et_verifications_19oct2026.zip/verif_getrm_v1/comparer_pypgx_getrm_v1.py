"""
comparer_pypgx_getrm_v1.py : compare les diplotypes appelés par PyPGx (pgxrun/<GENE>/genotypes.zip) aux diplotypes de consensus GeT-RM
(Consolidated_PGx-HLA_table_1-22-25-V4.xlsx, CDC) pour les échantillons présents dans le corpus v4.
Règles de comparaison (écrites avant de regarder les résultats) :
 - un diplotype est un ensemble non ordonné de 2 allèles ;
 - les parenthèses de GeT-RM (allèle probable non confirmé) sont retirées ;
 - si GeT-RM donne plusieurs possibilités (« or », « , »), le diplotype PyPGx est accepté s'il correspond à l'une d'elles (classé « ambigu_accepte ») ;
 - GeT-RM ne teste qu'une liste limitée d'allèles : un désaccord ne prouve pas une erreur de PyPGx, il est listé tel quel.
Usage : python3 comparer_pypgx_getrm_v1.py --getrm <xlsx> --corpus <csv> --pgxrun <dossier> --sortie <dossier>
"""
import argparse, re, zipfile, os
import pandas as pd

def alleles(s):
    s = re.sub(r'[()]', '', str(s)).strip()
    parts = [p.strip() for p in s.split('/')]
    return tuple(sorted(parts)) if len(parts) == 2 else None

def options(s):
    s = str(s)
    opts = re.split(r'\s+or\s+|,', s)
    out = [alleles(o) for o in opts if o.strip()]
    return [o for o in out if o]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--getrm', required=True); ap.add_argument('--corpus', required=True)
    ap.add_argument('--pgxrun', required=True); ap.add_argument('--sortie', required=True)
    a = ap.parse_args()
    g = pd.read_excel(a.getrm, sheet_name='PGx HLA Genotypes', header=1, dtype=str)
    g.columns = [str(c).strip().replace('\n', ' ') for c in g.columns]
    g = g.set_index(g.iloc[:, 1].astype(str).str.strip())
    corp = set(pd.read_csv(a.corpus, usecols=['sample_id']).sample_id.astype(str))
    com = [i for i in g.index if i in corp]
    print('échantillons GeT-RM :', len(g), '| présents dans le corpus :', len(com))
    colonne = {'NAT2': [c for c in g.columns if c.startswith('NAT2')][0], 'CYP3A4': 'CYP3A4', 'CYP4F2': 'CYP4F2', 'CYP1A2': 'CYP1A2', 'CYP2A6': 'CYP2A6'}
    lignes = []
    for gene, c in colonne.items():
        z = zipfile.ZipFile(os.path.join(a.pgxrun, gene, 'genotypes.zip'))
        py = pd.read_csv(z.open([x for x in z.namelist() if x.endswith('data.tsv')][0]), sep='\t', index_col=0)['Genotype']
        for sid in com:
            ref = g.at[sid, c]
            if pd.isna(ref): continue
            p = alleles(py.get(sid, ''))
            opts = options(ref)
            if p is None or not opts: statut = 'non_comparable'
            elif len(opts) == 1: statut = 'accord' if p == opts[0] else 'desaccord'
            else: statut = 'ambigu_accepte' if p in opts else 'desaccord'
            lignes.append(dict(gene=gene, sample_id=sid, getrm=ref, pypgx=py.get(sid, ''), statut=statut))
    d = pd.DataFrame(lignes)
    os.makedirs(a.sortie, exist_ok=True)
    d.to_csv(os.path.join(a.sortie, 'comparaison_pypgx_getrm_v1_detail.csv'), index=False)
    r = d.pivot_table(index='gene', columns='statut', values='sample_id', aggfunc='count', fill_value=0)
    r['total'] = r.sum(axis=1)
    r['concordance_%'] = ((r.get('accord', 0) + r.get('ambigu_accepte', 0)) / (r['total'] - r.get('non_comparable', 0)) * 100).round(1)
    r.to_csv(os.path.join(a.sortie, 'comparaison_pypgx_getrm_v1_resume.csv'))
    print(r.to_string())
    print('\nDésaccords :'); print(d[d.statut == 'desaccord'].to_string(index=False))

if __name__ == '__main__':
    main()
