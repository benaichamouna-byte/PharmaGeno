#!/bin/bash
# Random Forest puis DL (variante film) sur le corpus v4, protocole v8. XGBoost est déjà fait (resultats_v8/xgb).
cd /mnt/user-data/outputs
D=corpus_v4/phenotype_drug_dataset_v4.csv
F=/home/claude/drug_fingerprints_v2.pkl
( time python3 train_arbres_v8.py --data $D --fp $F --out resultats_v8/rf --modele rf --threads 2 ) > resultats_v8/rf_sortie.txt 2>&1
( time python3 train_dl_v8.py --data $D --fp $F --out resultats_v8/dl_film --variante film ) > resultats_v8/dl_film_sortie.txt 2>&1
echo FIN > resultats_v8/FIN_rf_dl.txt
