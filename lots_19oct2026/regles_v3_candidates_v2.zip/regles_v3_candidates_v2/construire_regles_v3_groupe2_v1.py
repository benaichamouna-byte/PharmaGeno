#!/usr/bin/env python3
"""
construire_regles_v3_groupe2_v1.py : règles CANDIDATES gène -> médicament -> action pour VKORC1, CYP4F2, CYP3A4, ADRB2, NAT2, IFNL3, MTHFR, SLC19A1, CFTR.
Source : textes complets (summary + texte + tableaux) des 18 annotations PharmGKB lues dans --ga ; chaque règle est écrite à la main d'après le texte lu
(identifiant de l'annotation + lien dans le CSV). N'écrase rien : le v1 (G6PD/HLA/MT-RNR1/RYR1) reste intact ; --v1 + groupe 2 -> regles_v3_candidates_v2.csv.
Vocabulaire : EVITER / ADAPTER_DOSE / SURVEILLER / STANDARD / NON_DETERMINE / AUCUNE_RECOMMANDATION / A_VALIDER.
Génotype inconnu -> NON_DETERMINE (jamais STANDARD).
Usage : python3 construire_regles_v3_groupe2_v1.py --ga DOSSIER_JSON --v1 regles_v3_candidates_v1.csv --sortie2 regles_v3_groupe2_v1.csv --sortie regles_v3_candidates_v2.csv
"""
import argparse, json, os
import pandas as pd

LIEN = 'https://www.pharmgkb.org/guidelineAnnotation/'
R = []
def add(gene, ph, med, brut, cl, org, force, cond, gid, lu='texte complet lu'):
    R.append(dict(gene=gene, phenotype_ou_allele=ph, medicament=med, action_brute=brut, action_classe_proposee=cl, organisme=org, force=force,
                  condition=cond, statut='candidate, à valider', statut_lecture=lu, id_guideline=gid, lien_pharmgkb=LIEN + gid))
NR = 'non relevée'
# ---- VKORC1 : DPWG (2018) ----
for gid, med, pct, extra in [('PA166104938', 'acenocoumarol', '50 %', 'Suivi INR plus fréquent (hors suivi par clinique d\'anticoagulation, la dose initiale est aussi à 50 %).'),
                             ('PA166104940', 'phenprocoumon', '50 %', 'Suivi INR plus fréquent ; algorithme EU-PACT non recommandé à partir de 75 ans.'),
                             ('PA166182841', 'warfarin', '60 %', 'Algorithme EU-PACT possible pour dose initiale et d\'entretien.')]:
    add('VKORC1', 'rs9923231 TT (-1639 AA)', med, 'DOSE_INITIALE_' + pct.replace(' %', 'PCT'), 'ADAPTER_DOSE', 'DPWG', NR, 'Dose initiale à ' + pct + ' de la dose standard. ' + extra, gid)
    add('VKORC1', 'rs9923231 CT (-1639 AG)', med, 'AUCUNE_ACTION', 'STANDARD', 'DPWG', NR, 'Aucune action requise (texte DPWG).', gid)
# ---- warfarine / VKA : CPIC 2017, CPNDS, RNPGx ----
G = 'PA166104949'
add('VKORC1/CYP2C9', 'génotype VKORC1 -1639G>A et CYP2C9 *2/*3 connu (ascendance non africaine)', 'warfarin', 'DOSE_PAR_ALGORITHME', 'ADAPTER_DOSE', 'CPIC', 'Strong',
    'Calculer la dose avec un algorithme pharmacogénétique publié (Gage ou IWPC). Dose de charge EU-PACT possible (Optional).', G)
add('VKORC1/CYP2C9', 'CYP2C9 métaboliseur lent (*2/*3, *3/*3) ou VKORC1 AA avec CYP2C9 métaboliseur lent', 'warfarin', 'ENVISAGER_ANTICOAGULANT_ALTERNATIF', 'ADAPTER_DOSE', 'CPIC', 'Strong',
    'Un anticoagulant oral alternatif peut être envisagé (texte CPIC 2017).', G)
add('CYP2C9', 'ascendance africaine, allèle CYP2C9 *5/*6/*8/*11', 'warfarin', 'REDUIRE_DOSE_15_30PCT', 'ADAPTER_DOSE', 'CPIC', NR,
    'Réduire la dose calculée de 15-30 % (20-40 % si deux allèles variants). Sans ces génotypes, doser cliniquement sans génotype.', G)
add('VKORC1/CYP2C9', 'génotype VKORC1/CYP2C9 inconnu', 'warfarin', 'NON_DETERMINE', 'NON_DETERMINE', 'CPIC', '', 'Doser cliniquement ; ne jamais traiter comme génotype normal.', G)
add('CYP4F2', 'V433M (rs2108622)', 'warfarin', 'TEST_NON_RECOMMANDE', 'AUCUNE_RECOMMANDATION', 'CPNDS', 'C - Optional',
    'CPNDS : test CYP4F2 V433M non recommandé actuellement. CPIC 2017 : l\'algorithme n\'inclut pas CYP4F2 ; à ajouter si le résultat est disponible.', 'PA166170752')
add('VKORC1/CYP2C9', 'génotype VKORC1 -1639G>A et CYP2C9 *2/*3 connu', 'warfarin', 'DOSE_PAR_ALGORITHME', 'ADAPTER_DOSE', 'CPNDS', 'A - Strong',
    'Interpréter avec un algorithme (variables cliniques + génétiques). Test à envisager avant ou dans les 2 premières semaines (B - Moderate). Ne remplace pas le suivi INR.', 'PA166170752')
add('VKORC1/CYP2C9', 'porteur VKORC1 -1639A ou CYP2C9 *2/*3', 'warfarin', 'DOSE_INITIALE_REDUITE_20_80PCT', 'ADAPTER_DOSE', 'RNPGx', NR,
    'Dose initiale réduite de 20 à 80 % de la dose standard selon génotype, AVK et cofacteurs ; orienter éventuellement vers un anticoagulant oral direct.', 'PA166202621')
for med in ('acenocoumarol', 'fluindione'):
    add('VKORC1/CYP2C9', 'porteur VKORC1 -1639A ou CYP2C9 *2/*3', med, 'DOSE_INITIALE_REDUITE_20_80PCT', 'ADAPTER_DOSE', 'RNPGx', NR,
        'Dose initiale réduite de 20 à 80 % selon génotype, AVK et cofacteurs ; orienter éventuellement vers un anticoagulant oral direct.', 'PA166202621')
# ---- IFNL3 ----
for med in ('peginterferon alfa-2a', 'peginterferon alfa-2b', 'ribavirin'):
    add('IFNL3', 'rs12979860 CC (génotype favorable)', med, 'REPONSE_FAVORABLE', 'A_VALIDER', 'CPIC', 'Strong',
        'Prédicteur de réponse (RVS ~70 % sous PEG-IFN + ribavirine, ~90 % avec inhibiteur de protéase, VHC génotype 1). Pas une consigne d\'éviter ni de dose : classe à décider.', 'PA166110235')
    add('IFNL3', 'rs12979860 CT ou TT (génotype défavorable)', med, 'REPONSE_DEFAVORABLE', 'A_VALIDER', 'CPIC', 'Strong',
        'RVS ~30 % sous PEG-IFN + ribavirine (~60 % avec inhibiteur de protéase) : « considérer les implications avant de débuter ». Pas une consigne d\'éviter ni de dose : classe à décider.', 'PA166110235')
# ---- CFTR / ivacaftor ----
P = 'PA166114461'
add('CFTR', 'G551D (AA ou AG, rs75527207), homozygote ou hétérozygote', 'ivacaftor', 'UTILISER_SELON_ETIQUETTE', 'STANDARD', 'CPIC', 'Strong', 'Utiliser l\'ivacaftor selon l\'étiquette du produit.', P)
add('CFTR', 'homozygote F508del (del/del)', 'ivacaftor', 'NON_RECOMMANDE', 'EVITER', 'CPIC', 'Moderate', 'Peu probable de répondre ; ivacaftor seul non recommandé.', P)
add('CFTR', 'un variant de la liste étiquette FDA (96 variants dans la mise à jour d\'août 2025)', 'ivacaftor', 'UTILISER_SELON_ETIQUETTE', 'STANDARD', 'CPIC', 'Moderate', 'Utiliser selon l\'étiquette ; liste complète dans l\'annotation.', P)
add('CFTR', 'autre génotype CFTR non listé', 'ivacaftor', 'NON_DETERMINE', 'NON_DETERMINE', 'CPIC', '', 'Hors tableau CPIC.', P)
add('CFTR', 'R117H, adulte ≥ 18 ans, ou enfant 6-17 ans avec VEMS < 90 %', 'ivacaftor', 'RECOMMANDATION_CONDITIONNELLE_POUR', 'STANDARD', 'CFF', 'conditionnelle', 'Nécessite âge et VEMS (ppFEV1).', 'PA166178241')
add('CFTR', 'R117H, enfant 12-17 ans avec VEMS > 90 %, ou enfant < 6 ans', 'ivacaftor', 'RECOMMANDATION_CONDITIONNELLE_CONTRE', 'EVITER', 'CFF', 'conditionnelle', 'Nécessite âge et VEMS (ppFEV1).', 'PA166178241')
add('CFTR', 'mutation de gating autre que G551D/R117H, ≥ 6 ans', 'ivacaftor', 'RECOMMANDATION_CONDITIONNELLE_POUR', 'STANDARD', 'CFF', 'conditionnelle', 'Texte CFF 2018.', 'PA166178241')
add('CFTR', 'au moins une copie G551D, ≥ 6 ans', 'ivacaftor', 'RECOMMANDATION_FORTE_POUR', 'STANDARD', 'CFF', 'strong', 'Texte CFF 2013 cité dans l\'annotation.', 'PA166178241')
# ---- CYP3A4 ----
add('CYP3A4', 'métaboliseur lent, indication dépression', 'quetiapine', 'CHOISIR_UNE_ALTERNATIVE', 'EVITER', 'DPWG', NR, 'Choisir une alternative (aripiprazole moins dépendant de CYP3A4 ; olanzapine non métabolisée par CYP3A4). Nécessite l\'indication.', 'PA166265421')
add('CYP3A4', 'métaboliseur lent, autres indications', 'quetiapine', 'DOSE_30PCT', 'ADAPTER_DOSE', 'DPWG', NR, 'Utiliser 30 % de la dose normale. Nécessite l\'indication.', 'PA166265421')
add('CYP3A4', 'métaboliseur intermédiaire', 'quetiapine', 'AUCUNE_ACTION', 'STANDARD', 'DPWG', NR, 'Aucune action requise. Le texte DPWG utilise d\'anciens noms d\'allèles CYP3A4.', 'PA166265421')
add('CYP3A4', 'tous génotypes', 'paclitaxel', 'AUCUNE_ACTION', 'STANDARD', 'DPWG', NR, 'DPWG : pas d\'interaction gène-médicament.', 'PA166265202')
for med in ('atorvastatin', 'fluvastatin', 'lovastatin', 'pitavastatin', 'pravastatin', 'rosuvastatin', 'simvastatin'):
    add('CYP3A4/CYP3A5/HMGCR', 'tous génotypes', med, 'AUCUNE_RECOMMANDATION', 'AUCUNE_RECOMMANDATION', 'CPIC', 'preuve faible', 'Aucune recommandation CPIC 2022 pour CYP3A4/5 et HMGCR (les règles SLCO1B1/ABCG2/CYP2C9 restent dans regles_v2).', 'PA166273401')
add('CYP3A4/CYP3A5', 'CYP3A5 expresseur (*1/*3 ou *1/*1)', 'tacrolimus', 'DOSE_x1,5_a_2', 'ADAPTER_DOSE', 'RNPGx', NR, '1,5 à 2 fois la dose des non-expresseurs, maximum 0,30 mg/kg/jour, guidé par le suivi thérapeutique (TDM). Test CYP3A5 « conseillé ».', 'PA166202481')
add('CYP3A4/CYP3A5', 'CYP3A5 non-expresseur (*3/*3)', 'tacrolimus', 'DOSE_0,15MG_KG', 'STANDARD', 'RNPGx', NR, '0,15 mg/kg/jour, guidé par le TDM. CYP3A4*22 : bénéfice à évaluer.', 'PA166202481')
# ---- ADRB2 ----
for med in ('carvedilol', 'labetalol', 'nadolol', 'pindolol', 'propranolol', 'sotalol'):
    add('ADRB2', 'tous génotypes', med, 'AUCUNE_RECOMMANDATION', 'AUCUNE_RECOMMANDATION', 'CPIC', 'niveau C', 'Preuves insuffisantes (CPIC juillet 2024).', 'PA166341524')
# ---- NAT2 / hydralazine ----
H = 'PA166416341'
add('NAT2', 'métaboliseur rapide', 'hydralazine', 'DOSE_DEPART_AU_MOINS_75MG', 'ADAPTER_DOSE', 'CPIC', 'Moderate', 'Dose de départ ≥ 75 mg/j, titrer jusqu\'à 300 mg/j (dose d\'entretien 50-100 % plus élevée que chez les lents).', H)
add('NAT2', 'métaboliseur intermédiaire', 'hydralazine', 'DOSE_DEPART_AU_MOINS_75MG', 'ADAPTER_DOSE', 'CPIC', 'Moderate', 'Dose de départ ≥ 75 mg/j, titrer jusqu\'à 300 mg/j.', H)
add('NAT2', 'métaboliseur lent', 'hydralazine', 'DOSE_DEPART_40_75MG', 'ADAPTER_DOSE', 'CPIC', 'Moderate', 'Départ 40-75 mg/j, titrer prudemment ; prudence ≥ 200 mg/j (lupus médicamenteux).', H)
add('NAT2', 'indéterminé', 'hydralazine', 'AUCUNE_RECOMMANDATION', 'AUCUNE_RECOMMANDATION', 'CPIC', '', 'Allèle de fonction incertaine.', H)
add('NAT2', 'génotype NAT2 inconnu', 'hydralazine', 'NON_DETERMINE', 'NON_DETERMINE', 'CPIC', '', 'Ne jamais traiter comme normal (aucun phénotype « normal » dans la guideline).', H)
# ---- MTHFR / SLC19A1 ----
add('MTHFR', 'rs1801133 (677C>T) tous génotypes', 'folic acid', 'AUCUNE_ACTION', 'STANDARD', 'DPWG', NR, 'DPWG 2021 : aucune action.', 'PA166264981')
add('MTHFR', 'rs1801133 (677C>T) tous génotypes', 'methotrexate', 'PAS_D_INTERACTION', 'STANDARD', 'DPWG', NR, 'DPWG 2021 : pas une interaction gène-médicament.', 'PA166265001')
for g in ('MTHFR', 'SLC19A1', 'ABCB1', 'SLCO1B1'):
    add(g, 'tous génotypes', 'methotrexate', 'TEST_POTENTIELLEMENT_UTILE', 'AUCUNE_RECOMMANDATION', 'RNPGx', 'potentiellement utile', 'Pas d\'action de dose. DISCORDANCE avec DPWG pour MTHFR (pas d\'interaction), conservée telle quelle.', 'PA166202781')

def main():
    ap = argparse.ArgumentParser()
    for k in ('ga', 'v1', 'sortie2', 'sortie'): ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    d2 = pd.DataFrame(R)
    manque = [i for i in d2.id_guideline.unique() if not os.path.exists(os.path.join(a.ga, i + '.json'))]
    assert not manque, manque
    d2.to_csv(a.sortie2, index=False)
    v1 = pd.read_csv(a.v1)
    tot = pd.concat([v1, d2], ignore_index=True)
    assert tot.duplicated(['gene', 'phenotype_ou_allele', 'medicament', 'organisme', 'id_guideline']).sum() == 0
    tot.to_csv(a.sortie, index=False)
    print('groupe 2 :', len(d2), 'règles,', d2.medicament.nunique(), 'médicaments,', d2.id_guideline.nunique(), 'annotations')
    print('total v2 :', len(tot), 'règles,', tot.medicament.nunique(), 'médicaments')
    print(d2.action_classe_proposee.value_counts().to_string())

if __name__ == '__main__':
    main()
