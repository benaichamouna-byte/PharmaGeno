#!/usr/bin/env python3
"""agreger_reco_v1.py (8 nov. 2026) : applique comparer_reco_v1.py (règles figées) aux 104 personnes. Aucune règle n'est modifiée ici."""
import sys, os, csv, collections, glob, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comparer_reco_v1 as C
SC = '/tmp/claude-0/-home-claude/8409b04b-17f7-52aa-bb79-1c3b814505b7/scratchpad/'
ech = [l.strip() for l in open(SC + 'getrm/liste_104_gelee.txt') if l.strip()]
def app_json(s):
    for d in ('app104_a', 'app104_b'):
        p = SC + 'recocmp/%s/sortie_%s.json' % (d, s)
        if os.path.exists(p): return p
rows = []; manq = []
for s in ech:
    a = app_json(s)
    if not a: manq.append(s); continue
    rows += C.comparer(s, SC + 'getrm/pc104/multi104.%s.report.json' % s, a)
out = SC + 'recocmp/resultat/'; os.makedirs(out, exist_ok=True)
with open(out + 'detail_reco_104.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['personne', 'medicament', 'guide', 'statut', 'texte_PharmCAT', 'texte_app', 'phenotypes']); w.writerows(rows)
cnt = collections.Counter(r[3] for r in rows)
print('personnes traitées', len(ech) - len(manq), 'manquantes', manq)
for k, v in cnt.most_common(): print('%-34s %6d' % (k, v))
subst = sum(v for k, v in cnt.items() if k not in ('ABSTENTION_PHARMCAT', 'ACCORD_PAS_DE_RECO', 'ABSENT_PHARMCAT'))
couv = subst - cnt['ABSENT_APP'] - cnt['APP_SANS_TEXTE']
print('annotations PharmCAT avec recommandation :', subst, '| dont couvertes par un texte de l\'application :', couv, '| identiques :', cnt['IDENTIQUE'], '=> %.1f %% des couvertes' % (100 * cnt['IDENTIQUE'] / couv if couv else 0))
# motifs distincts
mot = collections.defaultdict(set)
for r in rows:
    if r[3] not in ('IDENTIQUE', 'ABSTENTION_PHARMCAT', 'ACCORD_PAS_DE_RECO', 'ABSENT_APP', 'ABSENT_PHARMCAT', 'APP_SANS_TEXTE'): mot[(r[1], r[2], r[3], r[4], r[5])].add(r[0])
with open(out + 'motifs_differences_104.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['medicament', 'guide', 'statut', 'texte_PharmCAT', 'texte_app', 'nb_personnes', 'exemple_personne']); 
    for k, v in sorted(mot.items(), key=lambda x: (-len(x[1]), x[0])): w.writerow(list(k) + [len(v), sorted(v)[0]])
print('motifs distincts de différence :', len(mot))
# par personne x médicament
pm = collections.defaultdict(set)
for r in rows:
    if r[3] not in ('ABSTENTION_PHARMCAT', 'ACCORD_PAS_DE_RECO', 'ABSENT_PHARMCAT', 'ABSENT_APP', 'APP_SANS_TEXTE'): pm[(r[0], r[1], r[2])].add(r[3])
tot = len(pm); ok = sum(1 for v in pm.values() if v == {'IDENTIQUE'}); print('personne x médicament x guide comparables :', tot, '| tous identiques :', ok, '| %.1f %%' % (100 * ok / tot if tot else 0))
