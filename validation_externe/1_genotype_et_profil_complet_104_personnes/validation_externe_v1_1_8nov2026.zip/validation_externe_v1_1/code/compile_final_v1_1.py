import csv, collections, json, statistics, math, sys
D='/home/claude/appdev/Model_v8_7_9_10/data/'
R=list(csv.DictReader(open('sortie_v1_1/verdict_par_regle_auto_v1.csv')))
R1={r['regle_idx']:r for r in csv.DictReader(open('sortie_v1/verdict_par_regle_auto_v1.csv'))}
N=list(csv.DictReader(open('relecture_notes.csv')))
notes={int(n['regle_idx']):n for n in N}
Rb={int(r['regle_idx']):r for r in R}
combo=lambda r:(r['gene'],r['medicament'],r['etat_regle'],r['action'])
bycombo={}
for i,n in notes.items():
    r=Rb[i]
    if r['gene']=='G6PD': bycombo[(r['gene'],r['medicament'],r['valeur'])]=n
    elif r['gene']=='CYP3A5': bycombo[(r['gene'],r['medicament'],'CYP3A5')]=n
    else: bycombo[combo(r)]=n
def relu_for(r):
    if r['gene']=='G6PD': return bycombo.get((r['gene'],r['medicament'],'0.0')) if r['valeur']=='0.0' else None
    if r['gene']=='CYP3A5' and r['medicament']=='tacrolimus': return bycombo.get((r['gene'],r['medicament'],'CYP3A5'))
    return bycombo.get(combo(r))
def groupe(v):
    if v.startswith('SOUTENUE'): return 'Soutenue'
    if v.startswith('MIXTE'): return 'Mixte (pour et contre)'
    if v.startswith('NON_SOUTENUE'): return 'Non soutenue (résultats nuls)'
    if v=='SIGNAL_NON_ORIENTE': return 'Signal non orienté'
    if v=='NON_TRANCHABLE': return 'Non tranchable'
    if v=='AUCUNE_ETUDE': return 'Aucune étude'
    return 'Études présentes, non appariées automatiquement'
out=[]
for r in R:
    n=relu_for(r); vf=n['verdict_relu'] if n else r['verdict_auto']
    out.append({'regle_idx':r['regle_idx'],'gene':r['gene'],'etat_regle':r['etat_regle'],'phenotype':r['phenotype'],'medicament':r['medicament'],'action_application':r['action'],'source_regle':r['source'],
      'sens_dose_regle':r['dose_regle'],'lignes_candidates':r['n_lignes_candidates'],'pmid_concordants':r['n_pmid_concordants'],'pmid_contre_hors_concordants':r['n_pmid_contre'],'pmid_signal_non_oriente':r['n_pmid_signal'],'pmid_douteux':r['n_pmid_douteux'],
      'part_concordante_desc':r['part_concordante_desc'],'verdict_auto_v1':R1[r['regle_idx']]['verdict_auto'],'verdict_auto_v1_1':r['verdict_auto'],
      'relecture':(n['relu'] if n else 'non relue'),'verdict_final':vf,'groupe_final':groupe(vf),'remarque_relecture':(n['remarque'] if n else ''),
      'liste_pmid_concordants':r['pmid_concordants'],'liste_pmid_contre':r['pmid_contre']})
with open('tableau_validation_externe_regles_v1_1.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
ordre=['Soutenue','Mixte (pour et contre)','Non soutenue (résultats nuls)','Signal non orienté','Non tranchable','Études présentes, non appariées automatiquement','Aucune étude']
acts=('EVITER','ADAPTER_DOSE','SURVEILLER')
tab=collections.Counter((o['action_application'],o['groupe_final']) for o in out)
syn=[]
for a in acts+('TOTAL',):
    row={'action':a,'n_regles':sum(1 for o in out if a=='TOTAL' or o['action_application']==a)}
    for g in ordre: row[g]=sum(tab[(x,g)] for x in acts) if a=='TOTAL' else tab[(a,g)]
    syn.append(row)
with open('synthese_validation_externe_v1_1.csv','w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(syn[0].keys())); w.writeheader(); w.writerows(syn)
for r in syn: print(r)
seen={}
for o in out: seen.setdefault((o['gene'],o['medicament'],o['etat_regle'],o['action_application']),o)
tabu=collections.Counter(o['groupe_final'] for o in seen.values())
print('combos',len(seen),[(g,tabu[g]) for g in ordre])
ech=json.load(open('echantillon_30_regles_seed20261108.json'))['echantillon30']
Ob={int(o['regle_idx']):o for o in out}
c=collections.Counter(Ob[i]['relecture'] for i in ech); print('échantillon',c)
k=c['AJUSTE']; n=30; p=k/n; z=1.96
lo=(p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n); hi=(p+z*z/(2*n)+z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
print('ajusté %d/30 = %.1f%% (Wilson 95%% %.1f–%.1f)'%(k,100*p,100*lo,100*hi))
print([(i,Ob[i]['verdict_auto_v1_1'],Ob[i]['verdict_final']) for i in ech if Ob[i]['relecture']=='AJUSTE'])
print('relecture globale',collections.Counter(o['relecture'] for o in out))
parts=[float(o['part_concordante_desc']) for o in out if o['part_concordante_desc']!='' and o['groupe_final'] in('Soutenue','Mixte (pour et contre)','Non soutenue (résultats nuls)')]
print('part concordante n=%d médiane %.2f Q1 %.2f Q3 %.2f'%(len(parts),statistics.median(parts),*[statistics.quantiles(parts,n=4)[j] for j in (0,2)]))
pc=set((o['gene'],o['medicament']) for o in out if int(o['lignes_candidates'])>0); pa=set((o['gene'],o['medicament']) for o in out)
print('couples',len(pa),'avec ligne',len(pc))
print({s:(sum(1 for o in out if o['source_regle']==s),sum(1 for o in out if o['source_regle']==s and int(o['lignes_candidates'])>0),sum(1 for o in out if o['source_regle']==s and o['groupe_final'] in ('Soutenue','Mixte (pour et contre)'))) for s in sorted(set(o['source_regle'] for o in out))})
# nuls v. concordants totaux (PMID) pour règles soutenue/mixte/non soutenue
