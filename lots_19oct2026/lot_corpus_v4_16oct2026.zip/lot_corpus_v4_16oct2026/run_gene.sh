#!/bin/bash
# calcule PyPGx 0.27.0 pour un gène sur les 1379 échantillons ; sorties dans /home/claude/pgxrun/GENE
set -e
. /home/claude/pgxenv/bin/activate
export PYPGX_BUNDLE=/home/claude/sbslee/pypgx-bundle
G=$1; D=/home/claude/pgxrun/$G; mkdir -p $D
if [ -e $D/phenotypes.zip ] || [ -e $D/.lock ]; then echo SKIP $G; exit 0; fi
touch $D/.lock
python - <<PY
import pysam
ids=set(open('/home/claude/ids_1379.txt').read().split())
v=pysam.VariantFile('/home/claude/sbslee/pypgx-bundle/1kgp/GRCh38/$G.vcf.gz'); keep=[s for s in v.header.samples if s in ids]
print('$G','echantillons trouvés',len(keep),'sur',len(ids))
v.subset_samples(keep)
o=pysam.VariantFile('$D/sub.vcf.gz','wz',header=v.header)
for r in v.fetch(): o.write(r)
o.close(); pysam.tabix_index('$D/sub.vcf.gz',preset='vcf',force=True)
PY
pypgx import-variants $G $D/sub.vcf.gz $D/imported.zip --assembly GRCh38
pypgx predict-alleles $D/imported.zip $D/alleles.zip
pypgx call-genotypes $D/genotypes.zip --alleles $D/alleles.zip
pypgx call-phenotypes $D/genotypes.zip $D/phenotypes.zip
echo FINI $G
