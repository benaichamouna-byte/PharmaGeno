#!/usr/bin/env python3
"""comparer_reco_v1.py — règles de comparaison FIGÉES le 8 nov. 2026 (avant le calcul sur les 104 personnes).
Question : pour la même personne et le même médicament, la recommandation CPIC/DPWG affichée par l'application (v8s) est-elle la même que celle de PharmCAT 3.4.0 ?
Unité : une annotation PharmCAT (personne, médicament, guide CPIC ou DPWG, ligne de recommandation) ; et en sens inverse une règle de l'application.
Règles :
 R1 texte : HTML retiré, minuscules, entités décodées, lettres de notes isolées retirées, tout sauf [a-z0-9%≤≥<>] remplacé par un espace.
 R2 deux textes concordent si : ratio difflib complet >= 0.93, OU ratio sur les L premiers caractères (L = min(longueurs, 160)) >= 0.95, OU le plus court (>= 25 caractères) est inclus dans le plus long.
 R3 abstention PharmCAT : texte contenant « does not provide a recommendation » ou commençant par « no recommendation » : exclue des dénominateurs, comptée à part.
 R4 texte de l'application sans contenu : vide, commençant par « api cpic », contenant « pas de recommandation » : « app_sans_texte ».
 R5 statut d'une annotation PharmCAT (substantive) : IDENTIQUE si un texte de règle de l'application (même médicament, même guide) concorde (R2) ; sinon, sur les règles de l'application de même médicament et même guide :
    aucune règle -> ABSENT_APP ; une règle a les mêmes gènes (hors « No Result ») et les mêmes valeurs -> TEXTE_DIFFERENT_MEME_PHENOTYPE ; mêmes gènes, valeurs différentes -> PHENOTYPE_DIFFERENT ;
    sinon -> GENES_NON_ALIGNES (la règle de l'application n'utilise pas le même ensemble de gènes) ; valeur non convertible -> PHENOTYPE_NON_COMPARABLE.
    Si la seule règle de l'application n'a pas de contenu (R4) -> APP_SANS_TEXTE.
 R6 sens inverse : règle de l'application avec texte, aucune annotation PharmCAT du même médicament et du même guide -> ABSENT_PHARMCAT ; annotations présentes mais aucune concordante -> déjà comptée côté PharmCAT.
 R7 valeurs : phénotype PharmCAT -> valeur par codage_pypgx_valeur_v7.csv ; score d'activité numérique (CYP2C9, DPYD) divisé par 2 ; G6PD : normal 1.0, deficient 0.0, variable 0.5 ;
    VKORC1 (dict rsID) : valeur = nombre d'allèles de référence / 2 (CC 1.0, CT 0.5, TT 0.0) ; phénotype « Indeterminate »/« Unknown » côté PharmCAT -> statut PHARMCAT_INDETERMINE.
 R8 accord « pas de recommandation » : PharmCAT s'abstient (R3) et la règle de l'application n'a pas de contenu (R4) -> ACCORD_PAS_DE_RECO.
"""
import csv, json, re, html, difflib, collections
COD = {r['phenotype_pypgx'].lower(): r['valeur'] for r in csv.DictReader(open('/home/claude/appdev/Model_v8_7_9_10/data/codage_pypgx_valeur_v7.csv'))}
def norm(t):
    t = html.unescape(re.sub(r'<[^>]+>', ' ', t or '')).lower()
    t = re.sub(r'(?<=\s)[a-g](,[a-g])*(?=\s|\.|$)', ' ', t)
    t = re.sub(r'[^a-z0-9%≤≥<>]+', ' ', t); return re.sub(r'\s+', ' ', t).strip()
def concordent(a, b):
    if not a or not b: return False
    if difflib.SequenceMatcher(None, a, b).ratio() >= 0.93: return True
    L = min(len(a), len(b), 160)
    if difflib.SequenceMatcher(None, a[:L], b[:L]).ratio() >= 0.95: return True
    s, l = (a, b) if len(a) <= len(b) else (b, a)
    return len(s) >= 25 and s in l
def abstention(n): return bool(re.search(r'does not provide (a )?recommendation', n)) or n.startswith('no recommendation')
def sans_contenu(n): return (not n) or n.startswith('api cpic') or 'pas de recommandation' in n
def keyval(gene, v):
    if isinstance(v, dict):
        if gene == 'VKORC1':
            ref = [x for kk, x in v.items() if 'reference' in kk]; var = [x for kk, x in v.items() if 'variant' in kk]
            return (float(ref[0]) if ref else 0.0) / 2 if (ref or var) else None
        return None
    k = str(v).strip().lower()
    if k in ('indeterminate', 'unknown'): return 'IND'
    if gene == 'G6PD' and k in ('normal', 'deficient', 'variable'): return {'normal': 1.0, 'deficient': 0.0, 'variable': 0.5}[k]
    if re.fullmatch(r'\d+(\.\d+)?', k): return float(k) / 2 if gene in ('CYP2C9', 'DPYD') else None
    return float(COD[k]) if COD.get(k, '') != '' and k in COD else None
def pc_annots(path):
    j = json.load(open(path)); out = collections.defaultdict(list)
    for sname, key in (('CPIC', 'CPIC Guideline Annotation'), ('DPWG', 'DPWG Guideline Annotation')):
        for drug, d in j['drugs'].get(key, {}).items():
            for g in d['guidelines']:
                for a in g['annotations']:
                    lk = {}
                    for item in (a.get('lookupKey') or []):
                        for gene, v in item.items():
                            if isinstance(v, str) and v.lower() == 'no result': continue
                            lk[gene] = v
                    out[(drug.lower(), sname)].append({'texte': a['drugRecommendation'], 'lookup': lk})
    return out
def comparer(sample, pcjson, appjson):
    P = pc_annots(pcjson); A = json.load(open(appjson)); rules = collections.defaultdict(list); rows = []
    for e in A['moteur']:
        for rg in e.get('regle_cpic', []):
            if rg['source'] in ('CPIC', 'DPWG'):
                rules[(e['medicament'].lower(), rg['source'])].append({'n': norm(rg['texte']), 'genes': list(rg.get('genes') or []), 'val': list(rg.get('valeurs') or []), 'action': rg.get('action'), 'pheno': rg.get('phenotype'), 'e': e})
    for key in sorted(set(P) | set(rules)):
        med, src = key; ra = rules.get(key, []); pa = P.get(key, [])
        matched_rules = set()
        for p in pa:
            n = norm(p['texte'])
            if abstention(n):
                rows.append((sample, med, src, 'ACCORD_PAS_DE_RECO' if (ra and all(sans_contenu(r['n']) for r in ra)) else 'ABSTENTION_PHARMCAT', n[:80], '', '')); continue
            hit = [i for i, r in enumerate(ra) if concordent(n, r['n'])]
            if hit: matched_rules.update(hit); rows.append((sample, med, src, 'IDENTIQUE', n[:80], ra[hit[0]]['n'][:80], '')); continue
            if not ra: rows.append((sample, med, src, 'ABSENT_APP', n[:80], '', '')); continue
            if all(sans_contenu(r['n']) for r in ra): rows.append((sample, med, src, 'APP_SANS_TEXTE', n[:80], ra[0]['n'][:80], '')); continue
            pg = set(p['lookup']); st = None; best = None
            for r in ra:
                if sans_contenu(r['n']): continue
                if set(r['genes']) == pg:
                    pv = {g: keyval(g, v) for g, v in p['lookup'].items()}
                    if any(v == 'IND' for v in pv.values()): s2 = 'PHARMCAT_INDETERMINE'
                    elif any(v is None for v in pv.values()): s2 = 'PHENOTYPE_NON_COMPARABLE'
                    elif all(abs(pv[g] - float(rv)) < 1e-9 for g, rv in zip(r['genes'], r['val'])): s2 = 'TEXTE_DIFFERENT_MEME_PHENOTYPE'
                    else: s2 = 'PHENOTYPE_DIFFERENT'
                    rank = {'TEXTE_DIFFERENT_MEME_PHENOTYPE': 0, 'PHARMCAT_INDETERMINE': 1, 'PHENOTYPE_NON_COMPARABLE': 2, 'PHENOTYPE_DIFFERENT': 3}
                    if st is None or rank[s2] < rank[st]: st = s2; best = r
            if st is None: st = 'GENES_NON_ALIGNES'; best = ra[0]
            rows.append((sample, med, src, st, n[:80], best['n'][:80], '%s | app:%s%s %s | pc:%s' % ('', best['genes'], best['val'], best['pheno'], p['lookup'])))
        for i, r in enumerate(ra):
            if i in matched_rules or sans_contenu(r['n']): continue
            if not pa: rows.append((sample, med, src, 'ABSENT_PHARMCAT', '', r['n'][:80], ''))
    return rows
