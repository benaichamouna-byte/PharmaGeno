#!/usr/bin/env python3
"""agreger_reco_v1_1.py — AMENDEMENT 1 (8 nov. 2026, 21h15), décidé APRÈS avoir vu les résultats v1 (agreger_reco_v1.py, conservé tel quel).
Raison : la v1 compte comme « différence » chaque annotation PharmCAT que l'application n'affiche pas, y compris les annotations alternatives de PharmCAT pour la MÊME personne
(diplotypes ambigus, population adulte/pédiatrique, indications différentes pour le clopidogrel). La question posée est : la recommandation AFFICHÉE par l'application se retrouve-t-elle chez PharmCAT ?
Métrique A1 (centrée sur l'application) : pour chaque règle CPIC/DPWG de l'application avec contenu (R4), RETROUVEE si un texte PharmCAT de la même personne, même médicament, même guide concorde (R2, inchangée).
 sinon PHARMCAT_SANS_RECO (aucune annotation PharmCAT avec recommandation pour ce médicament et ce guide) ou NON_RETROUVEE (PharmCAT a d'autres recommandations).
Équivalences lues à la main (4 motifs VKORC1, texte français de l'application) : voir EQUIV_MANUELLE ci-dessous, déclarées avant le calcul de A1.
"""
import sys, os, csv, json, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import comparer_reco_v1 as C
SC = '/tmp/claude-0/-home-claude/8409b04b-17f7-52aa-bb79-1c3b814505b7/scratchpad/'
EQUIV_MANUELLE = {  # (guide, début du texte normalisé de l'application) -> motif PharmCAT attendu (début)
    ('DPWG', 'vkorc1 ct 1639 ag aucune action'): 'no action is needed for this gene drug interaction',
    ('DPWG', 'vkorc1 rs9923231 tt 1639 aa 50 % de la dose initiale standard'): '50% of the standard initial dose',
}
def equiv(src, napp, pcs):
    for (g, deb), attendu in EQUIV_MANUELLE.items():
        if g == src and napp.startswith(deb) and any(attendu in p for p in pcs): return True
    return False
ech = [l.strip() for l in open(SC + 'getrm/liste_104_gelee.txt') if l.strip()]
def app_json(s):
    for d in ('app104_a', 'app104_b'):
        p = SC + 'recocmp/%s/sortie_%s.json' % (d, s)
        if os.path.exists(p): return p
rows = []
for s in ech:
    P = C.pc_annots(SC + 'getrm/pc104/multi104.%s.report.json' % s); A = json.load(open(app_json(s)))
    for e in A['moteur']:
        for rg in e.get('regle_cpic', []):
            if rg['source'] not in ('CPIC', 'DPWG'): continue
            n = C.norm(rg['texte'])
            if C.sans_contenu(n): continue
            key = (e['medicament'].lower(), rg['source']); pcs = [C.norm(p['texte']) for p in P.get(key, [])]; subst = [p for p in pcs if not C.abstention(p)]
            if any(C.concordent(n, p) for p in subst): st = 'RETROUVEE'
            elif equiv(rg['source'], n, subst): st = 'RETROUVEE_EQUIV_MANUELLE'
            elif not subst: st = 'PHARMCAT_SANS_RECO'
            else: st = 'NON_RETROUVEE'
            rows.append((s, e['medicament'].lower(), rg['source'], st, n[:90], ' || '.join(p[:70] for p in subst)[:300], '%s%s %s' % (rg['genes'], rg['valeurs'], (rg.get('phenotype') or '')[:40])))
out = SC + 'recocmp/resultat/'
with open(out + 'detail_A1_centre_app_104.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['personne', 'medicament', 'guide', 'statut', 'texte_app', 'textes_PharmCAT', 'regle_app']); w.writerows(rows)
cnt = collections.Counter(r[3] for r in rows); tot = len(rows)
print('règles de l\'application avec contenu (personne x règle) :', tot)
for k, v in cnt.most_common(): print('%-28s %6d  %.1f %%' % (k, v, 100 * v / tot))
cmp_ = cnt['RETROUVEE'] + cnt['RETROUVEE_EQUIV_MANUELLE'] + cnt['NON_RETROUVEE']
print('comparables (PharmCAT a une recommandation) :', cmp_, '| retrouvées :', cnt['RETROUVEE'] + cnt['RETROUVEE_EQUIV_MANUELLE'], '| %.1f %%' % (100 * (cnt['RETROUVEE'] + cnt['RETROUVEE_EQUIV_MANUELLE']) / cmp_))
for g in ('CPIC', 'DPWG'):
    c = collections.Counter(r[3] for r in rows if r[2] == g); k = c['RETROUVEE'] + c['RETROUVEE_EQUIV_MANUELLE'] + c['NON_RETROUVEE']
    print(g, dict(c), '| retrouvées %.1f %% des comparables' % (100 * (c['RETROUVEE'] + c['RETROUVEE_EQUIV_MANUELLE']) / k))
mot = collections.defaultdict(set)
for r in rows:
    if r[3] == 'NON_RETROUVEE': mot[(r[1], r[2], r[4], r[6])].add(r[0])
with open(out + 'motifs_NON_RETROUVEE_A1.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['medicament', 'guide', 'texte_app', 'regle_app', 'nb_personnes', 'exemple'])
    for k, v in sorted(mot.items(), key=lambda x: -len(x[1])): w.writerow(list(k) + [len(v), sorted(v)[0]])
print('motifs NON_RETROUVEE :', len(mot), '| lignes :', cnt['NON_RETROUVEE'])
pm = collections.defaultdict(list)
for r in rows: pm[(r[0], r[1], r[2])].append(r[3])
cp = {k: v for k, v in pm.items() if any(x != 'PHARMCAT_SANS_RECO' for x in v)}
okp = sum(1 for v in cp.values() if all(x in ('RETROUVEE', 'RETROUVEE_EQUIV_MANUELLE', 'PHARMCAT_SANS_RECO') for x in v))
print('personne x médicament x guide comparables :', len(cp), '| toutes les règles de l\'application retrouvées :', okp, '| %.1f %%' % (100 * okp / len(cp)))
