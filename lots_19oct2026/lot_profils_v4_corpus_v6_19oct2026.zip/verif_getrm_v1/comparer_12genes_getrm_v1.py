"""
comparer_12genes_getrm_v1.py : compare le PHÉNOTYPE de nos profils (profils_genes_v3.csv, colonnes des gènes d'origine) au phénotype CPIC déduit du diplotype de consensus GeT-RM
(Consolidated_PGx-HLA_table_1-22-25-V4.xlsx) pour les échantillons en commun.
Chaîne : diplotype GeT-RM -> table CPIC distribuée dans le dépôt PharmCAT (phenotype/<GENE>.json, clé = comptage des allèles) -> codage du projet (codage_pypgx_valeur_v7.csv) -> comparaison à la valeur du profil.
Règles écrites avant de regarder les résultats :
 - parenthèses GeT-RM retirées ; plusieurs possibilités (« or », « , ») : accord si une possibilité donne la valeur du profil ;
 - diplotype absent de la table CPIC (notation non reconnue) -> « non_mappable » (non compté) ; phénotype CPIC « Indeterminate » -> « indetermine » (non compté) ;
 - GeT-RM ne teste qu'une liste limitée d'allèles : un désaccord ne prouve pas une erreur de notre profil ; il est listé tel quel.
Usage : python3 comparer_12genes_getrm_v1.py --getrm XLSX --profils profils_genes_v3.csv --phenodir DOSSIER_PHENOTYPE_PHARMCAT --codage codage_pypgx_valeur_v7.csv --sortie DOSSIER
"""
import argparse, json, os, re
import numpy as np, pandas as pd

GENES = ['CYP2B6', 'CYP2C9', 'CYP2C19', 'CYP2D6', 'CYP3A5', 'DPYD', 'NUDT15', 'SLCO1B1', 'TPMT', 'UGT1A1']
ALIAS_DPYD = {'*1': 'Reference'}

def table(phenodir, gene):
    d = json.load(open(os.path.join(phenodir, gene + '.json'), encoding='utf-8'))
    t = {}
    for x in d['diplotypes']:
        t[frozenset(x['diplotypekey'].items())] = x['phenotype']
    return t

def options(s):
    s = re.sub(r'[()]', '', str(s))
    out = []
    for o in re.split(r'\s+or\s+|,', s):
        p = [a.strip() for a in o.split('/')]
        if len(p) == 2 and all(p): out.append(p)
    return out

def main():
    ap = argparse.ArgumentParser()
    for k in ('getrm', 'profils', 'phenodir', 'codage', 'sortie'): ap.add_argument('--' + k, required=True)
    a = ap.parse_args(); os.makedirs(a.sortie, exist_ok=True)
    G = pd.read_excel(a.getrm, sheet_name='PGx HLA Genotypes', header=1, dtype=str)
    G.columns = [str(c).strip().replace('\n', ' ') for c in G.columns]
    G = G.set_index(G.iloc[:, 1].astype(str).str.strip())
    P = pd.read_csv(a.profils).set_index('sample_id') if 'sample_id' in pd.read_csv(a.profils, nrows=1).columns else pd.read_csv(a.profils, index_col=0)
    cod = pd.read_csv(a.codage).set_index('phenotype_pypgx')['valeur'].to_dict()
    com = [i for i in G.index if i in P.index]
    print('échantillons en commun :', len(com))
    rows = []
    for gene in GENES:
        t = table(a.phenodir, gene)
        for sid in com:
            col = gene if gene in G.columns else next((c for c in G.columns if c.startswith(gene + ' ')), None)   # DPYD : l'intitulé de colonne GeT-RM est long
            ref = G.at[sid, col] if col else np.nan
            if pd.isna(ref): continue
            nous = P.at[sid, gene]
            codes, phens, ok = [], [], False
            for o in options(ref):
                if gene == 'DPYD': o = [ALIAS_DPYD.get(x, x) for x in o]
                cnt = {}
                for x in o: cnt[x] = cnt.get(x, 0) + 1
                ph = t.get(frozenset(cnt.items()))
                if ph is not None: ok = True; phens.append(ph); codes.append(cod.get(ph, np.nan))
            if not ok: statut = 'non_mappable'
            elif all(pd.isna(c) for c in codes): statut = 'indetermine'
            elif pd.isna(nous): statut = 'profil_manquant'
            else:
                cc = [c for c in codes if not pd.isna(c)]
                statut = ('accord' if len(set(cc)) == 1 else 'ambigu_accepte') if any(abs(c - nous) < 1e-9 for c in cc) else 'desaccord'
            rows.append(dict(gene=gene, sample_id=sid, getrm=ref, phenotype_cpic='|'.join(phens), valeur_getrm='|'.join('' if pd.isna(c) else str(c) for c in codes), valeur_profil=nous, statut=statut))
    d = pd.DataFrame(rows); d.to_csv(os.path.join(a.sortie, 'comparaison_12genes_getrm_v1_detail.csv'), index=False)
    r = d.pivot_table(index='gene', columns='statut', values='sample_id', aggfunc='count', fill_value=0)
    for c in ('accord', 'ambigu_accepte', 'desaccord', 'non_mappable', 'indetermine', 'profil_manquant'):
        if c not in r.columns: r[c] = 0
    r['comparables'] = r['accord'] + r['ambigu_accepte'] + r['desaccord']
    r['concordance_%'] = ((r['accord'] + r['ambigu_accepte']) / r['comparables'].replace(0, np.nan) * 100).round(1)
    r = r[['accord', 'ambigu_accepte', 'desaccord', 'non_mappable', 'indetermine', 'profil_manquant', 'comparables', 'concordance_%']]
    r.to_csv(os.path.join(a.sortie, 'comparaison_12genes_getrm_v1_resume.csv')); print(r.to_string())
    print('\nDésaccords :'); print(d[d.statut == 'desaccord'].to_string(index=False))
    print('\nNon mappables (diplotype GeT-RM absent de la table CPIC) :'); print(d[d.statut == 'non_mappable'][['gene', 'sample_id', 'getrm']].to_string(index=False))

if __name__ == '__main__':
    main()
